package com.study.config;

import com.study.interceptor.LoggerInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(new LoggerInterceptor())
        .excludePathPatterns("/css/**", "/images/**", "/js/**");
    // src/main/resources 디렉터리의 static 폴더에 포함된 정적 리소스 파일을 제외하기 위해
    // excludePathPatterns( ) 메서드를 사용합니다.
    // addPathPatterns( )는 인터셉터 호출에서 경로를 추가(허용)한다는 의미
  }

}