package com.study.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.thymeleaf.util.StringUtils;

@Slf4j
@Aspect
@Component
public class LoggerAspect {

  @Around("execution(* com.study.domain..*Controller.*(..)) || execution(* com.study.domain..*Service.*(..)) || execution(* com.study.domain..*Mapper.*(..))")
  public Object printLog(ProceedingJoinPoint joinPoint) throws Throwable {

    String name = joinPoint.getSignature().getDeclaringTypeName();
    String type = StringUtils.contains(name, "Controller") ? "Controller ===> "
        : StringUtils.contains(name, "Service") ? "Service ===> "
            : StringUtils.contains(name, "Mapper") ? "Mapper ===> " : "";

    log.debug(type + name + "." + joinPoint.getSignature().getName() + "()");
    return joinPoint.proceed();
  }

}// api 호출 시간을 계산 할때 사용 하면 좋겠다.

// @Aspect
// @Component
// public class MethodExecutionCalculatorAspect {

// @Around("@annotation(MethodExecutionTime)")
// public Object calculateExecutionTime(ProceedingJoinPoint joinPoint) throws
// Throwable {
// long start = System.currentTimeMillis(); // 시작 시간을 기록합니다.
// Object result = joinPoint.proceed(); // 적용된 메서드를 실행합니다.
// long executionTime = System.currentTimeMillis() - start; // 실행 시간을 계산합니다.
// System.out.println(joinPoint.getSignature() + " executed in " + executionTime
// + "ms"); // 실행 시간을 출력합니다.
// return result; // 실행 결과를 반환합니다.
// }
// }

///////////////////////////////////////////////////////////
// @Retention(RetentionPolicy.RUNTIME)
// @Target(ElementType.METHOD)
// public @interface MethodExecutionTime {
// }

// @MethodExecutionTime
// public void someMethod() {
// // Method implementation
// }이제 이 메서드가 실행될 때, 위에서 정의한 어스펙트의 calculateExecutionTime 메서드가 실행될 것입니다
