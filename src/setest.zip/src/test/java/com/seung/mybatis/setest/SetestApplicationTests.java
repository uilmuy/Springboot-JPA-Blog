package com.seung.mybatis.setest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SetestApplicationTests {

	@Test
	void contextLoads() {
	}

}
