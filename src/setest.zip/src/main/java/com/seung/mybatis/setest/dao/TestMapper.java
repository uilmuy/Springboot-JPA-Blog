package com.seung.mybatis.setest.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.seung.mybatis.setest.dto.Company;
import com.seung.mybatis.setest.dto.Employee;

@Mapper
public interface TestMapper {
  public List<Company> selectSql();

  public Company selectOneSql();

  public List<Employee> selectCompanyId(int companyid);

  public int insertSql(String name, String address);

  public int updateCompany(int id, String address);
}
