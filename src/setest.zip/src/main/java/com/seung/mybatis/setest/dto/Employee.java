package com.seung.mybatis.setest.dto;

import lombok.Data;

@Data
public class Employee {
  private int id;
  private int companyid;
  private String name;
  private String address;
}
