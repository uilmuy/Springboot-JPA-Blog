package com.seung.mybatis.setest.controller;

//import java.util.HashMap;
import java.util.List;
//import java.util.Map;
//import java.util.Map;

//import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.seung.mybatis.setest.dao.TestMapper;
import com.seung.mybatis.setest.dto.Company;
import com.seung.mybatis.setest.service.CompanyService;

@RestController
@RequestMapping("/company")
public class CompanyController {

  // @Autowired
  // private CompanyMapper companyMapper;
  // @Autowired
  // private CompanyService companyService;
  @Autowired
  private TestMapper mapper;

  @Autowired
  private CompanyService companyService;

  // @PostMapping("")
  // public Company post(@RequestBody Company company) {
  // companyMapper.insert(company);
  // return company;
  // }

  @GetMapping("/all")
  public List<Company> getAll() {

    return mapper.selectSql();

  }

  @GetMapping("/one")
  public String getOne() {
    Company m;
    String text;
    m = mapper.selectOneSql();
    text = m.getName() + "얍마얍마";
    // System.out.println(text);
    return text;
  }

  @GetMapping("/two")
  public List<Company> getAll2() {
    return companyService.getAll();
  }

  @GetMapping(value = "/name")
  public String getName() {
    return "test";
  }

  @PostMapping(value = "/insertid")
  public void setInsert(@RequestBody Company company) {
    mapper.insertSql(company.getName(), company.getAddress());
  }

  @PutMapping("update/company/{id}")
  public Company updateCompany(@PathVariable int id, @RequestBody Company requestCompany) {
    mapper.updateCompany(id, requestCompany.getAddress());
    return requestCompany;
  }

  // @RequestMapping("listmap")
  // public String listmap(Model model) {

  // model.addAttribute("list", mapper.selectSql());

  // return "listmap";
  // }

  // @GetMapping("")
  // public List<Company> getAll() { //서비스 이용
  // return companyService.getAll();
  // }

  // @GetMapping("{idsel}")
  // public Company getId(@PathVariable int idsel) {
  // return companyMapper.getId(idsel);
  // }

}
