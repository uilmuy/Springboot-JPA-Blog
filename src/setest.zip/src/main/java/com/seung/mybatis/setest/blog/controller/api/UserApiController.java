package com.seung.mybatis.setest.blog.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.seung.mybatis.setest.blog.dto.ResponseDto;
import com.seung.mybatis.setest.blog.service.UserService;
import com.seung.mybatis.setest.dto.Company;

@RestController
public class UserApiController {

  @Autowired
  private UserService userService;

  @PostMapping("/api/user")
  public ResponseDto<Integer> save(@RequestBody Company company) {
    System.out.println("호출 잘됨");
    int result = userService.setCompanyInsert(company);
    return new ResponseDto<>(HttpStatus.OK, result);
  }
}
