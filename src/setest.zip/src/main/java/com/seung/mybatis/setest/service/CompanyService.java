package com.seung.mybatis.setest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seung.mybatis.setest.dao.TestMapper;
import com.seung.mybatis.setest.dto.Company;

@Service
public class CompanyService {

  @Autowired
  private TestMapper mapper;

  public List<Company> getAll() {
    List<Company> companyList = mapper.selectSql();
    if (companyList != null && companyList.size() > 0) {
      for (Company company : companyList) {
        company.setEmployeeList(mapper.selectCompanyId(company.getId()));
      }
    }
    return companyList;
  }

}
