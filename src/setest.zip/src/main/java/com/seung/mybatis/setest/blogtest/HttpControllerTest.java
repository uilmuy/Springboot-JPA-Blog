package com.seung.mybatis.setest.blogtest;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class HttpControllerTest {

}
