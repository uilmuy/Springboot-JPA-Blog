package com.seung.mybatis.setest.blog;

public enum EnumTest {
  남자, 여자, USER, ADMIN;
}
