package com.seung.mybatis.setest.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.seung.mybatis.setest.dao.TestMapper;
import com.seung.mybatis.setest.dto.Company;

@Service 
public class UserService {

  @Autowired
  private TestMapper mapper;

  @Transactional
  public int setCompanyInsert(Company company) {

    try {
      mapper.insertSql(company.getName(), company.getAddress());
      return 1;
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("UserService:회사입력:" + e.getMessage());
    }
    return -1;
  }

}
