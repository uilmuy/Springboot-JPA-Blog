let index = {
    init: function () {
        $("#btn-save").on("click",() =>{ //function(){}을 사용하지 않고 ()=>{}사용하는 것은 this를 바인딩 하기 위해서이다.
                this.save();
            }
        );
    },
    save:function(){
        // alert('함수호출');
        let data = {
            name: $("#name").val(),
            address: $("#address").val()
        };
        //console.log(data); ajax호출시 default가 비동기 호출
        
        $.ajax({
                type: "POST",
                url:"/api/user",
                data:JSON.stringify(data),
                contentType:"application/json;charset=utf-8", 
                dataType:"json" //ajax가 통신을 성공하면 json을 리턴햐주면서 자동으로 자바 오브잭트로 변환해준다?(생략가능)
            }).done(function(resp){
                alert("회사정보가 입력되었습니다.");
                //console.log(resp);
                location.href = "/"
            }).fail(function(error){
                alert(JSON.stringify(error));
            });
    }
}
index.init();