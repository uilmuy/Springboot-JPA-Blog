## 로또 번호 생성 프로젝트

### Tool

- VScode

### 스프링부트

- java 8
- SpringBoot ^2.6.10
- JPA
- Mysql
- Gradle
- Lombok
- Spring Security
- mustache
- Spring mail
