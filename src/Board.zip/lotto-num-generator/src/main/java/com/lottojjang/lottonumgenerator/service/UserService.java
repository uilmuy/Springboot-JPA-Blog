package com.lottojjang.lottonumgenerator.service;

import java.util.Optional;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lottojjang.lottonumgenerator.domain.User;
import com.lottojjang.lottonumgenerator.domain.Visit;
import com.lottojjang.lottonumgenerator.dto.user.PasswordResetReqDto;
import com.lottojjang.lottonumgenerator.dto.user.UpdateReqDto;
import com.lottojjang.lottonumgenerator.handler.ex.CustomApiException;
import com.lottojjang.lottonumgenerator.handler.ex.CustomException;
import com.lottojjang.lottonumgenerator.repository.UserRepository;
import com.lottojjang.lottonumgenerator.repository.VisitRepository;
import com.lottojjang.lottonumgenerator.util.email.EmailUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service // IoC 등록
public class UserService {

  // DI
  private final VisitRepository visitRepository;
  private final UserRepository userRepository;
  private final BCryptPasswordEncoder bCryptPasswordEncoder;
  private final EmailUtil emailUtil;

  @Transactional
  public void passwordResetExecute(PasswordResetReqDto passwordResetReqDto) {
    String useremail = "";
    String subject = "[Lotto JJang]비밀번호 초기화";
    StringBuilder emailcontents = new StringBuilder();
    emailcontents.append("초기화 된 임시 비밀번호 :");

    int leftLimit = 48; // 아스키 코드 리밋
    int rightLimit = 122;
    int targetStringLength = 10;
    Random random = new Random();
    String randompassword = random.ints(leftLimit, rightLimit + 1)
        .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
        .limit(targetStringLength)
        .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
        .toString();

    emailcontents.append(randompassword);
    // 1. username, email 이 같은 것이 있는지 체크 (DB)
    Optional<User> userOp = userRepository.findByUsernameAndEmail(
        passwordResetReqDto.getUsername(),
        passwordResetReqDto.getEmail());

    // 2. 같은 것이 있다면 DB password 초기화 - BCrypt 해시 - update 하기 (DB)
    if (userOp.isPresent()) {
      User userEntity = userOp.get(); // 영속화
      useremail = userEntity.getEmail();
      String encPassword = bCryptPasswordEncoder.encode(randompassword);
      userEntity.setPassword(encPassword);
    } else {
      throw new CustomException("해당 이메일이 존재하지 않습니다.");
    }

    // 3. 초기화된 비밀번호 이메일로 전송
    emailUtil.sendEmail(useremail, subject, emailcontents.toString());
  } // 더티체킹 (update)

  @Transactional
  public User signUp(User user) {
    // 1. save 한번
    String rawPassword = user.getPassword(); // 1234
    String encPassword = bCryptPasswordEncoder.encode(rawPassword); // 해쉬 알고리즘
    user.setPassword(encPassword);
    if (user.getNickname() == "") {
      user.setNickname(user.getUsername());
    }

    User userEntity = userRepository.save(user);

    // 2. save 두번
    Visit visit = new Visit();
    visit.setTotalCount(0L);
    visit.setUser(userEntity);
    visitRepository.save(visit);

    return userEntity;
  }

  public boolean sameNameChk(String username) {

    Optional<User> userOp = userRepository.findByUsername(username);

    if (userOp.isPresent()) {
      return false;
    } else {
      return true;
    }
  }

  @Transactional
  public boolean userUpdate(UpdateReqDto updateReqDto) { // TODO 회원정보 변경 후 세션처리
    Optional<User> userOp = userRepository.findById(updateReqDto.getId());

    if (userOp.isPresent()) {
      User user = userOp.get();
      BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

      if (!passwordEncoder.matches(updateReqDto.getPassword(), user.getPassword())) {
        throw new CustomApiException("{패스워드가 틀립니다. 수정할 수 없습니다.}");

      } else {// 패스워드가 맞을경우.
        if (updateReqDto.getPassword() != updateReqDto.getNewpassword()) {
          String newEncPassword = bCryptPasswordEncoder.encode(updateReqDto.getNewpassword());
          user.setPassword(newEncPassword);
        }
        if (updateReqDto.getNickname() != user.getNickname()) {
          user.setNickname(updateReqDto.getNickname());
        }
        if (updateReqDto.getEmail() != user.getEmail()) {
          user.setEmail(updateReqDto.getEmail());
        }
      }

    }
    return false;
  }

}
