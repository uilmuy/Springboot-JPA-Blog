package com.lottojjang.lottonumgenerator.repository;

import java.util.List;
import java.util.Optional;

import com.lottojjang.lottonumgenerator.domain.LottoNumberET;
import com.lottojjang.lottonumgenerator.domain.LottoWinnerNum;

public interface LottoWinnerInfoRepository {

  boolean save(LottoWinnerNum lwn);

  Optional<LottoWinnerNum> findById(int id);

  List<LottoWinnerNum> findAll();

  List<LottoWinnerNum> findByValue(LottoNumberET lwe);

  Long lastRoundNum();

  // List<LottoWinnerNum> findByOneYearNum(int ftnum, int lastnum); //범위 회차정보 가져오기

}
