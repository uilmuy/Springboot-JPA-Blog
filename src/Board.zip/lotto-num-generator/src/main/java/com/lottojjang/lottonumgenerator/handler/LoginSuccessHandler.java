package com.lottojjang.lottonumgenerator.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.lottojjang.lottonumgenerator.config.auth.LoginUser;
import com.lottojjang.lottonumgenerator.domain.User;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoginSuccessHandler implements AuthenticationSuccessHandler {

  @Override
  public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
      Authentication authentication) throws IOException, ServletException {

    LoginUser loginUser = (LoginUser) authentication.getPrincipal();
    User principal = loginUser.getUser();
    // Authentication authentication = authenticationManager
    // .authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(),
    // user.getPassword()));
    // SecurityContextHolder.getContext().setAuthentication(authentication);

    HttpSession session = request.getSession();
    log.debug("세션아이디 :{}", session.getId());
    session.setAttribute("principal", principal); // 세션에 정보를 담는다.
    response.sendRedirect("/");

  }

}
