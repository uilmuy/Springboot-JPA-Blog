package com.lottojjang.lottonumgenerator.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.lottojjang.lottonumgenerator.dto.lotto.LottoWinner;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "lotto_winner_info")
@Data
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED) // 빈 생성자 사용금지
@Builder(builderMethodName = "LottoWinnerNumBuilder")
public class LottoWinnerNum {

  @Id
  private int drwNo;// 회차

  private int bnusNo; // 보너스 번호
  private int drwtNo1;
  private int drwtNo2;
  private int drwtNo3;
  private int drwtNo4;
  private int drwtNo5;
  private int drwtNo6;

  @Temporal(TemporalType.TIMESTAMP)
  private Date drwNoDate; // 추첨일

  private int firstPrzwnerCo; // 1등 티켓 갯수

  public static LottoWinnerNumBuilder builder(LottoWinner lottoWinner) {
    return LottoWinnerNumBuilder().bnusNo(lottoWinner.getBnusNo())
        .drwtNo1(lottoWinner.getDrwtNo1())
        .drwtNo2(lottoWinner.getDrwtNo2())
        .drwtNo3(lottoWinner.getDrwtNo3())
        .drwtNo4(lottoWinner.getDrwtNo4())
        .drwtNo5(lottoWinner.getDrwtNo5())
        .drwtNo6(lottoWinner.getDrwtNo6())
        .drwNo(lottoWinner.getDrwNo())
        .drwNoDate(lottoWinner.getDrwNoDate())
        .firstPrzwnerCo(lottoWinner.getFirstPrzwnerCo());
  }

}
