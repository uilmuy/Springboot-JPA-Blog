package com.lottojjang.lottonumgenerator.util;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lottojjang.lottonumgenerator.dto.lotto.LottoWinner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.htmlparser.jericho.Element;
import net.htmlparser.jericho.Source;

public class LottoInfoCollector {

  private static Logger logger = LoggerFactory.getLogger(LottoInfoCollector.class);

  /**
   * 현 로또 사업자 홈페이지에서 제공하는 API URL
   * 
   * @see #getLastLottoInfoFromNanumWeb2()
   */
  private static final String WINNER_INFO_API_URL = "https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=";

  /**
   * 현 로또 사업자 홈페이지
   * 
   * @see # public int getLastLottoDrwNo()
   */
  private static final String LOTTO_HOME_MAIN_URL = "https://www.dhlottery.co.kr/common.do?method=main";

  /**
   * 현 로또 사업자 홈페이지
   * 
   * @see # public int getWinnerinfo()
   */
  private static final String LOTTO_HOME_SUB_URL = "https://dhlottery.co.kr/gameResult.do?method=byWin";

  /**
   * 회차 번호에 대한 로또 추첨 정보를 얻어 온다.
   *
   * @param findDrwNo 정보를 얻고자 하는 추첨회차
   * @return LottoWinner 찾은 로또 추첨 정보 error is null return
   * @exception
   * @see
   **/
  public static LottoWinner getLottoWinnerInfo(int findDrwNo) {

    try {

      Source source = new Source(new URL(WINNER_INFO_API_URL + findDrwNo));
      logger.debug(source.getSource().toString());

      ObjectMapper mapper = new ObjectMapper();
      JsonNode jsonObject = mapper.readTree(source.getSource().toString());

      logger.debug("#####################################################################");
      logger.debug("getLottoWinnerInfo#########################################");
      logger.debug("url:" + WINNER_INFO_API_URL + findDrwNo);
      logger.debug("drwNo : " + jsonObject.get("drwNo"));
      logger.debug("drwNoDate : " + jsonObject.get("drwNoDate").textValue());
      logger.debug("firstPrzwnerCo : " + jsonObject.get("firstPrzwnerCo"));
      logger.debug("bnusNo : " + jsonObject.get("bnusNo"));
      logger.debug("drwtNo1 : " + jsonObject.get("drwtNo1"));
      logger.debug("drwtNo2 : " + jsonObject.get("drwtNo2"));
      logger.debug("drwtNo3 : " + jsonObject.get("drwtNo3"));
      logger.debug("drwtNo4 : " + jsonObject.get("drwtNo4"));
      logger.debug("drwtNo5 : " + jsonObject.get("drwtNo5"));
      logger.debug("drwtNo6 : " + jsonObject.get("drwtNo6"));
      logger.debug("returnValue : " + jsonObject.get("returnValue").textValue());

      if (jsonObject.get("returnValue").textValue().equals("success")) {

        // 회차
        int drwNo = Integer.parseInt(jsonObject.get("drwNo").toString());

        // 추첨일
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date drwNoDateConv = format.parse((jsonObject.get("drwNoDate").textValue()));

        // 1등 티켓 갯수
        int firstPrzwnerCo = Integer.parseInt(jsonObject.get("firstPrzwnerCo").toString());

        // 보너스 번호
        int bnusNo = Integer.parseInt(jsonObject.get("bnusNo").toString());
        int drwtNo1 = Integer.parseInt(jsonObject.get("drwtNo1").toString());
        int drwtNo2 = Integer.parseInt(jsonObject.get("drwtNo2").toString());
        int drwtNo3 = Integer.parseInt(jsonObject.get("drwtNo3").toString());
        int drwtNo4 = Integer.parseInt(jsonObject.get("drwtNo4").toString());
        int drwtNo5 = Integer.parseInt(jsonObject.get("drwtNo5").toString());
        int drwtNo6 = Integer.parseInt(jsonObject.get("drwtNo6").toString());

        return LottoWinner.builder()
            .bnusNo(bnusNo)
            .drwNo(drwNo)
            .drwtNo1(drwtNo1)
            .drwtNo2(drwtNo2)
            .drwtNo3(drwtNo3)
            .drwtNo4(drwtNo4)
            .drwtNo5(drwtNo5)
            .drwtNo6(drwtNo6)
            .drwNoDate(drwNoDateConv)
            .firstPrzwnerCo(firstPrzwnerCo)
            .build();

      } else {
        logger.warn("getLottoWinnerInfo return is fail");
      }

    } catch (Exception e) {
      logger.debug(e.getMessage());
    }

    return null;
  }

  /**
   * 마지막 회차 번호 를 얻어 온다.
   *
   * @param
   * @return 마지막 회차 번호 error is 0 return
   * @exception
   * @see
   **/
  public static int getLastLottoDrwNo() {

    int returnValue = 0;

    try {
      Source source = new Source(new URL(LOTTO_HOME_MAIN_URL));
      List<Element> els = source.getAllElements("strong");

      for (int iCount = 0; iCount < els.size(); iCount++) {
        Element el = els.get(iCount);

        if (el.getAttributeValue("id") != null) {
          if (el.getAttributeValue("id").equals("lottoDrwNo")) {
            returnValue = Integer.parseInt(el.getContent().toString());
          }
        }

      }
    } catch (Exception e) {
      returnValue = 0;
      logger.debug(e.getMessage());
    }

    return returnValue;
  }

  // public static String getWinnerinfo() { //

  // int returnValue = 0;

  // try {
  // Source source = new Source(new URL(LOTTO_HOME_SUB_URL));

  // // List<Element> els = source.getAllElements("strong");

  // // for (int iCount = 0; iCount < els.size(); iCount++) {
  // // Element el = els.get(iCount);

  // // if (el.getAttributeValue("id") != null) {
  // // if (el.getAttributeValue("id").equals("lottoDrwNo")) {
  // // returnValue = Integer.parseInt(el.getContent().toString());
  // // }
  // // }

  // // }
  // return source.toString();
  // } catch (Exception e) {
  // returnValue = 0;
  // logger.debug(e.getMessage());
  // }

  // return null;
  // }
}
