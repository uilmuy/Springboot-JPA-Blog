package com.lottojjang.lottonumgenerator.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lottojjang.lottonumgenerator.domain.MyLottoNum;

public interface MyLottoRepository extends JpaRepository<MyLottoNum, Integer> {

}
