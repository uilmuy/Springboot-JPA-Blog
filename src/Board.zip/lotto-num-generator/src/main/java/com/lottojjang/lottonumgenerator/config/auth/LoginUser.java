package com.lottojjang.lottonumgenerator.config.auth;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.lottojjang.lottonumgenerator.domain.User;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class LoginUser implements UserDetails {

  private final User user;

  /**
   * 해당 유저의 권한을 가져오는 메소드
   *
   * @return
   */
  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {

    Collection<GrantedAuthority> collectors = new ArrayList<>();
    /*
     * collectors.add(new GrantedAuthority() {
     * 
     * @Override
     * public String getAuthority() {
     * return "ROLE_"+user.getRole(); //스프링에서 권한을 받을때의 규칙으로 "ROLE_"+를 꼭 넣어야 한다.
     * (ROLE_USER,ROLE_ADMIN)
     * }
     * });
     */
    collectors.add(() -> {
      return "ROLE_" + user.getRole();
    });

    return collectors;
  }

  @Override
  public String getPassword() {
    return user.getPassword();

  }

  @Override
  public String getUsername() {
    return user.getUsername();
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  public boolean isEnabled() {
    return true;
  }

}
