package com.lottojjang.lottonumgenerator.util.email;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Component
public class EmailUtil {
  private final JavaMailSender sender;

  public void sendEmail(String toAddress, String subject, String body) {
    log.debug("바디 내용 : {}", body);
    MimeMessage message = sender.createMimeMessage();
    MimeMessageHelper helper = new MimeMessageHelper(message);
    try {
      helper.setTo(toAddress);
      helper.setSubject(subject);
      helper.setText(body);
    } catch (MessagingException e) {
      e.printStackTrace();
    }

    sender.send(message);

  }
}
