package com.lottojjang.lottonumgenerator.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.lottojjang.lottonumgenerator.domain.WinnerInfomation;
import com.lottojjang.lottonumgenerator.repository.WinnerInfomationRepository;
import com.lottojjang.lottonumgenerator.util.LottoInfoCollector;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MainController {

  @Autowired
  private WinnerInfomationRepository winnerInfomationRepository;

  @GetMapping({ "/" })
  public String main() {
    int max = LottoInfoCollector.getLastLottoDrwNo();
    return "redirect:/" + max;
  }

  @GetMapping({ "/{drwNo}" })
  public String main1(@PathVariable int drwNo, Model model) { // TODO 마지막 주차인지 홈페이지에서 확인하고 마지막 주차가 아니면 크롤링 해와야함

    // System.out.println("뭐 나오냐?" + winDrwNoList.get(0));
    Optional<WinnerInfomation> winnerInfomation = winnerInfomationRepository.findByDrwNoOne(drwNo);
    if (winnerInfomation.isPresent()) {
      WinnerInfomation winnerInfomationEntity = winnerInfomation.get();
      model.addAttribute("winnerInfomation", winnerInfomationEntity);

    } else {
      // TODO 동행drwNo와 저장된 winnerInfomation.drwNo가 다르면 처리하기 (크롤링 혹은 "없음 표시")
      log.info("내용이 없습니다.");
    }
    return "main";

  }
}
