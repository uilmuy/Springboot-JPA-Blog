package com.lottojjang.lottonumgenerator.domain;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LottoNumber {

  private Long id;

  @Builder.Default
  private int drwtNo1 = 0;

  @Builder.Default
  private int drwtNo2 = 0;

  @Builder.Default
  private int drwtNo3 = 0;

  @Builder.Default
  private int drwtNo4 = 0;

  @Builder.Default
  private int drwtNo5 = 0;

  @Builder.Default
  private int drwtNo6 = 0;

  private int drwNo; // 대상 회차

  private Date createDate; // 생성일
  private boolean isGood; // true 당첨

  @Builder.Default
  private int emptyDigit = 6; // 생성 되어야 할 빈 자릿수 수

}
