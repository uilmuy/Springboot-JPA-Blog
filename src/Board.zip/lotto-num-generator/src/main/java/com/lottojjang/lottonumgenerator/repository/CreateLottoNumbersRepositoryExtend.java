package com.lottojjang.lottonumgenerator.repository;

import java.util.List;

import com.lottojjang.lottonumgenerator.domain.LottoNumberET;

public interface CreateLottoNumbersRepositoryExtend {

  List<LottoNumberET> findByValue(LottoNumberET lwe);

  int isExist(LottoNumberET lwe);
}
