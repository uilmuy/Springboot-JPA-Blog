package com.lottojjang.lottonumgenerator.repository.impl;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lottojjang.lottonumgenerator.domain.LottoNumberET;
import com.lottojjang.lottonumgenerator.domain.LottoWinnerNum;
import com.lottojjang.lottonumgenerator.repository.LottoWinnerInfoRepository;

public class LottoWinnerInfoRepositoryImpl implements LottoWinnerInfoRepository {

  Logger logger = LoggerFactory.getLogger(LottoWinnerInfoRepositoryImpl.class);

  private final EntityManager em;

  public LottoWinnerInfoRepositoryImpl(EntityManager em) {
    this.em = em;
  }

  @Override
  public boolean save(LottoWinnerNum lwn) {

    try {
      this.em.persist(lwn);

    } catch (Exception e) {
      logger.debug(e.getMessage());
      return false;
    }

    return true;
  }

  @Override
  public Optional<LottoWinnerNum> findById(int id) {
    return Optional.ofNullable(this.em.find(LottoWinnerNum.class, id));
  }

  @Override
  public List<LottoWinnerNum> findAll() {
    return this.em.createQuery("select m from LottoWinneNum m", LottoWinnerNum.class).getResultList();
  }

  @Override
  public List<LottoWinnerNum> findByValue(LottoNumberET lwe) {

    List<LottoWinnerNum> result = this.em.createQuery(
        "select m from LottoWinnerNum m where m.drwtNo1 = :drwtNo1 " +
            "and m.drwtNo2 = :drwtNo2 " +
            "and m.drwtNo3 = :drwtNo3 " +
            "and m.drwtNo4 = :drwtNo4 " +
            "and m.drwtNo5 = :drwtNo5 " +
            "and m.drwtNo6 = :drwtNo6",
        LottoWinnerNum.class)
        .setParameter("drwtNo1", lwe.getDrwtNo1())
        .setParameter("drwtNo2", lwe.getDrwtNo2())
        .setParameter("drwtNo3", lwe.getDrwtNo3())
        .setParameter("drwtNo4", lwe.getDrwtNo4())
        .setParameter("drwtNo5", lwe.getDrwtNo5())
        .setParameter("drwtNo6", lwe.getDrwtNo6())
        .getResultList();

    return result;

  }

  // @Override
  // public List<LottoWinnerNum> findByOneYearNum(int ftnum, int lastnum) {

  // List<LottoWinnerNum> result = this.em.createQuery(
  // "select m from LottoWinnerNum m where drwNo between :ftnum and :lastnum",
  // // "and 1000 ",
  // LottoWinnerNum.class)
  // .setParameter("ftnum", ftnum)
  // .setParameter("lastnum", lastnum)
  // .getResultList();

  // return result;

  // }

  @Override
  public Long lastRoundNum() {
    try {
      return Long
          .valueOf(this.em.createQuery("select  max(drwNo) from LottoWinnerNum ", Integer.class).getSingleResult());
    } catch (NullPointerException e) {
      logger.debug(e.getMessage());
    }
    return null;

  }

}
