package com.lottojjang.lottonumgenerator.controller;

import java.security.Principal;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lottojjang.lottonumgenerator.dto.user.JoinReqDto;
import com.lottojjang.lottonumgenerator.dto.user.PasswordResetReqDto;
import com.lottojjang.lottonumgenerator.dto.user.UpdateReqDto;
import com.lottojjang.lottonumgenerator.service.UserService;
import com.lottojjang.lottonumgenerator.util.UtilValid;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Controller
public class UserController {

  private final UserService userService;

  @GetMapping("/login-form")
  public String loginForm() {
    return "/user/loginForm";
  }

  @GetMapping("/join-form")
  public String joinForm() {
    return "/user/joinForm";
  }

  @GetMapping("/user")
  public @ResponseBody String user(Principal principal) {// @AuthenticationPrincipal User user 어노테이션은 유저의 로그인 객채를 가져올수 있다.
    return principal.getName();
  }

  @GetMapping("/user/{id}")
  public String updateForm() {
    return "/user/updateForm";
  }

  @GetMapping("/user/password-reset-form")
  public String passwordResetForm() {
    // log.debug("여기오니?");
    return "/user/passwordResetForm";
  }

  @PostMapping("/user/password-reset")
  public String passwordReset(@Valid PasswordResetReqDto passwordResetReqDto, BindingResult bindingResult) {

    UtilValid.requestHandler(bindingResult);
    userService.passwordResetExecute(passwordResetReqDto);

    return "redirect:/login-form";
  }

  // ResponseEntity 는 @ResponseBody를 붙이지 않아도 data를 리턴한다.
  @GetMapping("/api/user/username-same-check")
  public ResponseEntity<?> usernameSameCheck(String username) {
    boolean isNotSame = userService.sameNameChk(username); // true (같지 않다)
    return new ResponseEntity<>(isNotSame, HttpStatus.OK);
  }

  @PostMapping("/join")
  public String join(@Valid JoinReqDto joinReqDto, BindingResult bindingResult) {

    boolean bindErr = UtilValid.requestHandler(bindingResult);
    log.debug("벨리데이션 에러 발생 : {}", bindErr);
    userService.signUp(joinReqDto.toEntity());

    return "redirect:/login-form";
  }

  @PutMapping("/user/update")
  public ResponseEntity<?> update(@RequestBody @Valid UpdateReqDto updateReqDto, BindingResult bindingResult) {
    log.debug("=======================================================================");
    log.debug("updateDto1 : {}", updateReqDto.getId());
    log.debug("updateDto2 : {}", updateReqDto.getUsername());
    log.debug("updateDto3 : {}", updateReqDto.getPassword());
    log.debug("updateDto4 : {}", updateReqDto.getNewpassword());
    log.debug("updateDto5 : {}", updateReqDto.getEmail());
    log.debug("updateDto6 : {}", updateReqDto.getNickname());
    boolean bindErr = UtilValid.putRequestHandler(bindingResult);
    log.debug("벨리데이션 에러 발생 : {}", bindErr);
    boolean tranErr = userService.userUpdate(updateReqDto);
    log.debug("회원정보변경 에러 발생 : {}", tranErr);

    // if (!bindErr) {
    // return new ResponseEntity<>(bindErr,HttpStatus.OK);
    // } else {
    // return new ResponseEntity<>(bindErr,HttpStatus.BAD_REQUEST);
    // }
    return new ResponseEntity<>(HttpStatus.OK);
  }
}
