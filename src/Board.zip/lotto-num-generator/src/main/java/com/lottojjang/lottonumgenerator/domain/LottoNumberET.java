package com.lottojjang.lottonumgenerator.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "created_lotto_number")
@Data
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED) // 빈 생성자 사용금지 //TODO 이유물어보기
@Builder(builderMethodName = "LottoNumberETBuilder")
public class LottoNumberET {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private int drwtNo1;
  private int drwtNo2;
  private int drwtNo3;
  private int drwtNo4;
  private int drwtNo5;
  private int drwtNo6;
  private int drwNo; // 대상 회차

  @Temporal(TemporalType.TIMESTAMP)
  private Date createDate; // 생성일

  private boolean isGood; // true 당첨

  public static LottoNumberETBuilder builder(LottoNumber lottoNumber) {
    return LottoNumberETBuilder()
        .drwtNo1(lottoNumber.getDrwtNo1())
        .drwtNo2(lottoNumber.getDrwtNo2())
        .drwtNo3(lottoNumber.getDrwtNo3())
        .drwtNo4(lottoNumber.getDrwtNo4())
        .drwtNo5(lottoNumber.getDrwtNo5())
        .drwtNo6(lottoNumber.getDrwtNo6())
        .drwNo(lottoNumber.getDrwNo())
        .createDate(lottoNumber.getCreateDate());
  }

}
