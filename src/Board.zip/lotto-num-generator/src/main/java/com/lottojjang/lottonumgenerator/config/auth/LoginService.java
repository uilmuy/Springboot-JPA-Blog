package com.lottojjang.lottonumgenerator.config.auth;

import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lottojjang.lottonumgenerator.domain.User;
import com.lottojjang.lottonumgenerator.domain.Visit;
import com.lottojjang.lottonumgenerator.handler.ex.CustomException;
import com.lottojjang.lottonumgenerator.repository.UserRepository;
import com.lottojjang.lottonumgenerator.repository.VisitRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service // IoC 컨테이너 등록됨.
public class LoginService implements UserDetailsService {

  private final UserRepository userRepository;
  private final VisitRepository visitRepository;

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

    Optional<User> userOp = userRepository.findByUsername(username);

    if (userOp.isPresent()) {
      visitIncrease(userOp.get().getId());
      return new LoginUser(userOp.get());
    }
    return null;
  }

  // 방문수 증가
  @Transactional
  public void visitIncrease(Integer userid) {

    Optional<Visit> visitOp = visitRepository.findById(userid);

    if (visitOp.isPresent()) {
      Visit visitEntity = visitOp.get();
      Long totalCount = visitEntity.getTotalCount();
      visitEntity.setTotalCount(totalCount + 1);
      visitRepository.save(visitEntity); // 영속성 이놈아!!!! 왜!!!! 트랜젝션이 종료되지 않는지 모르겠다....
    } else {
      log.error("미친 심각", "회원가입할때 Visit이 안 만들어지는 심각한 오류가 있습니다.");
      throw new CustomException("일시적 문제가 생겼습니다. 관리자에게 문의해주세요.");
    }
  }

}
