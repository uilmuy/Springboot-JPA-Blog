package com.lottojjang.lottonumgenerator.dto.user;

public enum RoleType {
  USER, ADMIN
}
