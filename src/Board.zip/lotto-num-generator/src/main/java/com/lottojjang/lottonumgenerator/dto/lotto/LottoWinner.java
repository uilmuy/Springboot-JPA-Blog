package com.lottojjang.lottonumgenerator.dto.lotto;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LottoWinner {

  // private Long id;

  private int bnusNo; // 보너스 번호
  private int drwtNo1;
  private int drwtNo2;
  private int drwtNo3;
  private int drwtNo4;
  private int drwtNo5;
  private int drwtNo6;
  private int drwNo; // 회차
  private Date drwNoDate; // 추첨일
  private int firstPrzwnerCo; // 1등 티켓 갯수

}
