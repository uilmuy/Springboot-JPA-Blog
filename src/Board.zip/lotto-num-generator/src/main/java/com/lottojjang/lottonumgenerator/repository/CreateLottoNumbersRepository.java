package com.lottojjang.lottonumgenerator.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lottojjang.lottonumgenerator.domain.LottoNumberET;

public interface CreateLottoNumbersRepository
    extends JpaRepository<LottoNumberET, Long>, CreateLottoNumbersRepositoryExtend {

  // public List<LottoNumberET> findByValue(LottoNumberET lwe) {

  // List<LottoNumberET> result = this.em.createQuery(
  // "select m from LottoWinnerET m where m.drwtNo1 = :drwtNo1 " +
  // "and m.drwtNo2 = :drwtNo2 " +
  // "and m.drwtNo3 = :drwtNo3 " +
  // "and m.drwtNo4 = :drwtNo4 " +
  // "and m.drwtNo5 = :drwtNo5 " +
  // "and m.drwtNo6 = :drwtNo6",
  // LottoNumberET.class)
  // .setParameter("drwtNo1", lwe.getDrwtNo1())
  // .setParameter("drwtNo2", lwe.getDrwtNo2())
  // .setParameter("drwtNo3", lwe.getDrwtNo3())
  // .setParameter("drwtNo4", lwe.getDrwtNo4())
  // .setParameter("drwtNo5", lwe.getDrwtNo5())
  // .setParameter("drwtNo6", lwe.getDrwtNo6())
  // .getResultList();

  // return result;

  // }

}
