package com.lottojjang.lottonumgenerator.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import com.lottojjang.lottonumgenerator.handler.ex.CustomApiException;
import com.lottojjang.lottonumgenerator.handler.ex.CustomException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UtilValid {

  public static boolean requestHandler(BindingResult bindingResult) {

    if (bindingResult.hasErrors()) {
      Map<String, String> errorMap = new HashMap<>();
      for (FieldError fe : bindingResult.getFieldErrors()) {
        errorMap.put(fe.getField(), fe.getDefaultMessage());
      }
      // 이부분에서 data리턴인지 html 리턴인지 이것만 구분해서 !
      throw new CustomException(errorMap.toString());

    }
    return bindingResult.hasErrors();
  }

  public static boolean putRequestHandler(BindingResult bindingResult) {

    if (bindingResult.hasErrors()) {
      Map<String, String> errorMap = new HashMap<>();
      for (FieldError fe : bindingResult.getFieldErrors()) {
        errorMap.put(fe.getField(), fe.getDefaultMessage());
      }
      throw new CustomApiException(errorMap.toString());

    }
    return bindingResult.hasErrors();
  }
}
