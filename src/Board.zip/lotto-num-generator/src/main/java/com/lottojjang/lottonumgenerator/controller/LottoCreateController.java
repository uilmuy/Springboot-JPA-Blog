package com.lottojjang.lottonumgenerator.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lottojjang.lottonumgenerator.domain.LottoNumber;
import com.lottojjang.lottonumgenerator.dto.lotto.LottoNumberBuilder;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Controller
public class LottoCreateController {

  private final LottoNumberBuilder lottoNumberBuilder;

  @GetMapping("/lotto/createLottoNum")
  public @ResponseBody List<LottoNumber> lottoNumbuild() {

    List<Integer> includeNumbersList = new ArrayList<>();
    includeNumbersList.add(3);
    includeNumbersList.add(10);
    List<Integer> excludeNumbersList = new ArrayList<>();
    excludeNumbersList.add(7);
    try {
      List<LottoNumber> createLottoList = lottoNumberBuilder.createLottoNumber(2, includeNumbersList,
          excludeNumbersList);
      System.out.println(createLottoList.get(0));
      return createLottoList;
    } catch (NullPointerException e) {
      log.debug(e.getMessage());
      return null;
    }
    //

  }
}
