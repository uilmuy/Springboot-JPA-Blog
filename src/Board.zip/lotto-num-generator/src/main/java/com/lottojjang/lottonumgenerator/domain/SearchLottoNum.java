package com.lottojjang.lottonumgenerator.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@EntityListeners(AuditingEntityListener.class)
@Entity
public class SearchLottoNum {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  private int drwtNo1;
  private int drwtNo2;
  private int drwtNo3;
  private int drwtNo4;
  private int drwtNo5;
  private int drwtNo6;

  @CreatedDate // insert 할때만 동작
  private LocalDateTime createDate;

  @LastModifiedDate // update 할때만 동작
  private LocalDateTime updateDate;

  private boolean mBought; // 구매한 번호?

  private int targetDrwNo; // 기대 회차정보

  private boolean winWhether; // 당첨여부

  @ManyToOne
  @JoinColumn(name = "userId")
  private User user;

}
