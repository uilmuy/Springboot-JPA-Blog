package com.lottojjang.lottonumgenerator.controller;

import java.util.ArrayList;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lottojjang.lottonumgenerator.config.auth.LoginUser;
import com.lottojjang.lottonumgenerator.dto.lotto.LottowinConfirmation;
import com.lottojjang.lottonumgenerator.repository.WinnerInfomationRepository;
import com.lottojjang.lottonumgenerator.service.LottoWinnerInfoService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Controller
public class LottoController {

  private final LottoWinnerInfoService lottoWinnerInfoService;
  private final WinnerInfomationRepository winnerInfomationRepository;

  @GetMapping("/admin/lotto")
  public @ResponseBody String setLottoWinnerInfo() {// TODO 함수 이름 바꿀 것

    log.debug("전체 회차 정보 수집");

    try {
      if (lottoWinnerInfoService.saveAllWinnerInfo()) {
        return "It's OK!";
      }
    } catch (Exception e) {
      e.getStackTrace();
      // TODO 예외처리 마무리 할 것
    }

    return "It's FAIL!";

  }

  @ResponseBody
  @PostMapping("/lotto/{round}/winConfirmation") // 로또번호 검증 Validation 구현 @valid 해봐야 함.
  public ResponseEntity<?> winMyLotto(@RequestBody ArrayList<LottowinConfirmation> lottowinConfirmation,
      @PathVariable int round, @AuthenticationPrincipal LoginUser loginUser) {// r Model model

    int[] arrWinNum = lottoWinnerInfoService.winNumByRoundArr(round);
    String username = "Guest";

    try {
      if (loginUser.getUsername() != null) {
        username = loginUser.getUsername();
      }
    } catch (Exception e) {
      e.getStackTrace();
    }

    for (int i = 0; i < lottowinConfirmation.size(); i++) {
      lottoWinnerInfoService.chkNumMatch(lottowinConfirmation.get(i), arrWinNum);
    }
    lottoWinnerInfoService.saveSearchNumber(lottowinConfirmation, username); // db(serchLottobum 컬럼) save
    // LottoWinnerNum lottoWinnerNum = lottoWinnerInfoService.winNumByRound(round);
    // model.addAttribute("lottowinConfirmation", lottowinConfirmation);
    // model.addAttribute("lottoWinnerNum", lottoWinnerNum);
    return new ResponseEntity<>(lottowinConfirmation, HttpStatus.OK);

  }

  @ResponseBody // 1년(52주) 동안 당첨된 번호와 나의 번호 비교.
  @PostMapping("/lotto/winConfimOneYear") // 로또번호 검증 Validation 구현 @valid 해봐야 함.
  public ResponseEntity<?> winConfimOneYear(@RequestBody LottowinConfirmation lottowinConfirmation) {

    ArrayList<LottowinConfirmation> arrLwc = lottoWinnerInfoService.oneYearNumChk(lottowinConfirmation);

    return new ResponseEntity<>(arrLwc, HttpStatus.OK); // return ResponseEntity.ok(arrLwc);와 같음
    // return ResponseEntity.status(400).body(arrLwc);

  }

  @ResponseBody // 내가 조회한 번호 저장
  @PostMapping("/lotto/user/{username}/myLottoSave")
  public ResponseEntity<?> myLottoSave(@RequestBody ArrayList<LottowinConfirmation> arrLottowinConfirmation,
      @PathVariable String username) {
    String returnText = "";
    boolean saveOK = lottoWinnerInfoService.saveMyNumber(arrLottowinConfirmation, username);

    if (saveOK == true) {
      returnText = "저장완료";
    }
    return new ResponseEntity<>(returnText, HttpStatus.OK);
  }

  @GetMapping("/lotto/info/drwno") // ajax 리턴
  public @ResponseBody ArrayList<Integer> aaa(Model model) throws Exception {
    ArrayList<Integer> winDrwNoList = winnerInfomationRepository.findByDrwNoList();
    model.addAttribute("winDrwNoList", winDrwNoList);
    return winDrwNoList;
  }

}
