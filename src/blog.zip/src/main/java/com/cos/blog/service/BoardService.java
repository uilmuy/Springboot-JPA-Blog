package com.cos.blog.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cos.blog.dto.ReplySaveRequestDto;
import com.cos.blog.model.Board;
import com.cos.blog.model.User;
import com.cos.blog.repository.BoardRepository;
import com.cos.blog.repository.ReplyRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor // 초기화 되지 않은 것들을 생성자를 호출할때 초기화 해줘~
@Service // 스프링이 컴포넌트 스캔을 통해 bean에 등록 해 준다.
public class BoardService {
  // private BoardRepository boardRepository; //DI 하는 방법은 사실 어노테이션을 사용하지 않으면 다음과
  // 같이 IOC에 올린다.
  // private ReplyRepository replyRepository;

  // public BoardService(BoardRepository boardRepository, ReplyRepository
  // replyRepository) {
  // this.boardRepository = boardRepository;
  // this.replyRepository = replyRepository;
  // }

  // @Autowired
  // private BoardRepository boardRepository;

  // @Autowired
  // private ReplyRepository replyRepository;

  private final BoardRepository boardRepository; // DI이 할 것이 많아지면 @Autowired 를 사용하지 않고 @RequiredArgsConstructor을 사용하여
                                                 // DI하는 방법도 있다
  private final ReplyRepository replyRepository;

  @Transactional
  public void 글쓰기(Board board, User user) {

    board.setCount(0);
    board.setUser(user);
    boardRepository.save(board);

  }

  @Transactional(readOnly = true)
  public Page<Board> 글목록(Pageable pageable) {
    return boardRepository.findAll(pageable);
  }

  @Transactional(readOnly = true)
  public Board 글상세보기(int id) {
    return boardRepository.findById(id)
        .orElseThrow(() -> {
          return new IllegalArgumentException("아이디를 찾을 수 없습니다.");
        });

  }

  @Transactional
  public void 삭제하기(int id) {
    boardRepository.deleteById(id);

  }

  @Transactional
  public void 글수정(int id, Board requestBoard) {

    Board board = boardRepository.findById(id).orElseThrow(() -> { // 영속화
      return new IllegalArgumentException("글을 찾을수 없습니다.");
    });
    board.setTitle(requestBoard.getTitle()); // 영속화 객체의 데이터를 변경 하면 자동 업데이트
    board.setContent(requestBoard.getContent());
    // 해당 함수로 종료시(service가 종료될 때) 트랜잭션이 종료 된다. 이때 더티채킹이 일어나고 자동 업데이트(flush) 된다.
  }

  @Transactional
  public void 댓글쓰기(ReplySaveRequestDto replyDto) {
    /*
     * Board board =
     * boardRepository.findById(replyDto.getBoardId()).orElseThrow(()->{ //영속화
     * return new IllegalArgumentException("댓글:글을 찾을수 없습니다.");
     * });
     * User user = userRepository.findById(replyDto.getUserId()).orElseThrow(()->{
     * //영속화
     * return new IllegalArgumentException("댓글:사용자를 찾을수 없습니다.");
     * });
     * 
     * Reply reply= Reply.builder()
     * .board(board)
     * .user(user)
     * .content(replyDto.getContent())
     * .build();
     * 
     * replyRepository.save(reply);//replyRepository.save(new
     * Reply().replayUpdate(user, board, replyDto.getContent()));
     */
    replyRepository.mySave(replyDto.getUserId(), replyDto.getBoardId(), replyDto.getContent());
  }

  public void 댓글삭제하기(int replyId) {
    replyRepository.deleteById(replyId);
  }
  /*
   * public void insertFile(List<MultipartFile> fileList) throws Exception {
   * 
   * fileUtils.fileUpload(fileList);
   * 
   * 
   * }
   */

}
