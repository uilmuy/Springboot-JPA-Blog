package com.cos.blog.test;

import java.util.List;
import java.util.function.Supplier;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cos.blog.model.RoleType;
import com.cos.blog.model.User;
import com.cos.blog.repository.UserRepository;

@RestController
public class DummyConteollerTest {

	@Autowired // DI 하기전에는 컨테이너에 올라가 있지 않음.
	private UserRepository userRepository;

	// 입력
	@PostMapping("/dummy/join")
	// public String join(@RequestParam("username")String username,
	// @RequestParam("password")String password, @RequestParam("email")String email)
	// {
	// public String join(String username, String password, String email) {
	// //@postmapping은 메소드의 인자 값으로도 보낼 수 있다. key=value타입으로 전송하고 받는다.
	public String join(@RequestBody User user) {

		System.out.println(
				"username=" + user.getUsername() + "  password=" + user.getPassword() + "  email=" + user.getEmail());

		user.setRole(RoleType.USER);
		userRepository.save(user);
		return "회원가입이 완료 되었습니다.";
	}

	// {id}주소로 파라미터 값을 전달 받을 수 있음 파라미터 값은 @PathVariable로 주소형식:/blog/dummy/user/3
	@GetMapping("/dummy/user/{id}")
	public User detail(@PathVariable int id) {
		// findbyid 로 디비 접근시 데이터가 없으면 null값으로 반환 될 수 있기 때문에 optional로 형 변환 한다.
		/*
		 * User user = userRepository.findById(id).orElseGet(new Supplier<User>()
		 * 
		 * @Override public User get() { return new User(); //null일 경우 빈 객채를 리턴 해 준다. }
		 * });
		 */
		
		User user = userRepository.findById(id).orElseThrow(new Supplier<IllegalArgumentException>() {
			@Override
			public IllegalArgumentException get() {
				return new IllegalArgumentException("해당 아이디는 없습니다.id=" + id);
			}
		});

		/*
		 * 람다식 변환 User user = userRepository.findById(id).orElseThrow(()->{ return new
		 * IllegalArgumentException("해당 아이디는 없습니다.id="+id); });
		 */
		// user 객채는 java객체 이기 때문에 웹 브라우져는 객채를 이해하지 못한다.스프링 부트는 MessageConverter가 자동으로
		// 변환(Json)
		return user;

	}

	// https://www.youtube.com/watch?v=dPfjqBB-T4U&list=PL93mKxaRDidECgjOBjPgI3Dyo8ka6Ilqm&index=29
	// (참조)
	@GetMapping("/dummy/user/userlist")
	public List<User> list() {

		return userRepository.findAll();

	}

	// 한페이지당 2페이지 userpagelist?page=0 부터 시작
	@GetMapping("/dummy/user/userpagelist")
	/*
	 * public Page<User> pagelist(@PageableDefault(size = 2,sort ="id", direction =
	 * Sort.Direction.DESC) Pageable pageable){
	 * 
	 * Page<User> users = userRepository.findAll(pageable);
	 * 
	 * return users;
	 * 
	 * }
	 */
	public List<User> pagelist(
			@PageableDefault(size = 2, sort = "id", direction = Sort.Direction.DESC) Pageable pageable) {

		List<User> users = userRepository.findAll(pageable).getContent();

		return users;

	}

	// 업데이트
	// save합수는 id를 전달하지 않으면 insert를 해주고
	// " id를 전달하면 해당 id에대한 데이터가 있으면 update를 해준다.
	// 또, " id를 전달하고 해당 id의 데이터가 존제 하지 않으면 insert를 한다.
	@Transactional // 함수 종료시 자동 커밋
	@PutMapping("/dummy/user/{id}") // Json으로 받아 처리
	public User updateUser(@PathVariable int id, @RequestBody User requestUser) {

		User user = userRepository.findById(id).orElseThrow(() -> { // 수정시 먼저 데이터 베이스의 값이 있는지 확인 한다. orelseThrow를 사용하는
																	// 이유는
			return new IllegalArgumentException("해당 아이디는 없습니다."); // null값이 나오면 문제가 될 수 있기 때문이다.
		});
		user.setPassword(requestUser.getPassword()); // 불러온 데이터가 존재 할 경우 json으로 받은 값을 불러온 데이터 값에 업데이트를 진행하고 save 한다.
		user.setEmail(requestUser.getEmail()); // @Transactional 어노테이션을 붙이면 save 메소드를 호출하지 않아도 영속성 컨텍스트의 값의 변경을 확인하고
												// 업데이트
		// userRepository.save(user);

		return user;
	}
	@DeleteMapping("dummy/user/{id}")
	public String deleteUser(@PathVariable int id) {
		
		/*
		 * User user = userRepository.findById(id).orElseThrow(() -> { return new
		 * IllegalArgumentException("해당 아이디는 없습니다."); });
		 */
		try {
			userRepository.deleteById(id);
			return "데이터가 삭제되었습니다.";
		} catch (EmptyResultDataAccessException e) {
			return "해당 데이터가 없습니다.";
		}
		
		
	}
}























