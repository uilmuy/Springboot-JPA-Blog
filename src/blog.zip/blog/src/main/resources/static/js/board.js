let index = {
	init: function() {
		$("#btn-save").on("click", () => {
			this.save();
		});
		$("#btn-delete").on("click", () => {
			this.deleteById();
		});
		$("#btn-update").on("click", () => {
			this.update();
		});
		$("#btn-reply-save").on("click", () => {
			this.replySave();
		});


	},
	save: function() {
		//alert('잘 나오나.');
		var formData = new FormData();
		let data = {
			title: $("#title").val(),
			content: $("#content").val()
		};
		// input class 값
		var fileInput = $('.files');
		// fileInput 개수를 구한다.
		for (var i = 0; i < fileInput.length; i++) {
			if (fileInput[i].files.length > 0) {
				for (var j = 0; j < fileInput[i].files.length; j++) {
					console.log(" fileInput[i].files[j] :::" + fileInput[i].files[j]);

					// formData에 'file'이라는 키값으로 fileInput 값을 append 시킨다.  
					formData.append('file', $('.files')[i].files[j]);
				}
			}
		}
		// 'key'라는 이름으로 위에서 담은 data를 formData에 append한다. type은 json  
		formData.append('key', new Blob([JSON.stringify(data)], { type: "application/json" }));

		$.ajax({
			type: "POST",
			url: "/api/board",
			data: formData,
			//contentType: "application/json;charset=utf-8",
			contentType: false,               // * 중요 *
			processData: false,               // * 중요 *
			enctype: 'multipart/form-data',  // * 중요 *
			dataType: "json"
		}).done(function(resp) {                      //성공         
			alert("글쓰기가 완료되었습니다.");
			location.href = "/";
		}).fail(function(error) {                      //실패
			alert(JSON.stringify(error));
		});
	},
	deleteById: function() {
		let id = $("#id").text();  /*request로 넘어온 글id 값 가져오기*/

		$.ajax({
			type: "DELETE",
			url: "/api/board/" + id,
			dataType: "json"
		}).done(function(resp) {                      //성공         
			alert("삭제가  완료되었습니다.");
			location.href = "/";
		}).fail(function(error) {                      //실패
			alert(JSON.stringify(error));
		});
	},
	update: function() {
		let id = $("#id").val();

		let data = {
			title: $("#title").val(),
			content: $("#content").val()
		};

		$.ajax({
			type: "PUT",
			url: "/api/board/" + id,
			data: JSON.stringify(data),
			contentType: "application/json;charset=utf-8",
			dataType: "json"
		}).done(function(resp) {                      //성공         
			alert("글수정이 완료되었습니다.");
			location.href = "/";
		}).fail(function(error) {                      //실패
			alert(JSON.stringify(error));
		});
	},
	replySave: function() {
		//alert('잘 나오나.');
		let data = {
			userId: $("#userId").val(),
			boardId: $("#boardId").val(),
			content: $("#reply-content").val()
		};

		$.ajax({
			type: "POST",
			url: `/api/board/${data.boardId}/reply`, //숫자1 옆 ``을 사용하고 다음과 같이 사용하면 스크립트의 변수 값이 들어온다.
			data: JSON.stringify(data),
			contentType: "application/json;charset=utf-8",
			dataType: "json"
		}).done(function(resp) {                      //성공         
			alert("댓글 작성이 완료되었습니다.");
			location.href = `/board/${data.boardId}`;
		}).fail(function(error) {                      //실패
			alert(JSON.stringify(error));
		});
	},

	replyDelete: function(boardId, replyId) {
		//alert(replyId)

		$.ajax({
			type: "DELETE",
			url: `/api/board/${boardId}/reply/${replyId}`,
			dataType: "json"
		}).done(function(resp) {                      //성공         
			alert("댓글 삭제가 완료되었습니다.");
			location.href = `/board/${boardId}`;
		}).fail(function(error) {                      //실패
			alert(JSON.stringify(error));
		});
	},


}
index.init();