let index={
	init: function(){
		$("#btn-save").on("click",()=>{ //function()){}을 사용 하지 않고 ()=>을 사용하는 이유는 this를 바인딩 하기 위해서>
			this.save();
		});
		
		$("#btn-update").on("click",()=>{
			/*if($("#password").val().length==0)
			{
				alert("페스워드를 입력 하세요");
				$("#password").focus();
				return false;
			};*/
			this.update();
		});
		
	},
	save:function(){
		
		let data = {
			username: $("#username").val(),
			password: $("#password").val(),
			email: $("#email").val()
		};
		
		
		$.ajax({                                 
			type:"POST",
			url:"/auth/joinProc",
			data:JSON.stringify(data), //http body데이터
			contentType:"application/json;charset=utf-8", //보낼 바디 데이터가 어떤 데이터 인지
			dataType : "json" // 서버로 부터의 응답이 왔을때 생긴것이 json타입이면 자바스크립트 오브젝트 형태로 변환 하여 준다.
		}).done(function(resp){   //성공    
			if(resp.status==500){ //만약 에러(500)이면
				alert("회원 가입을 완료하지 못했습니다.");
			}else{
				alert("회원가입이 완료되었습니다.");
				location.href="/";
			} 
			//console.log(resp);
		}).fail(function(error){                      //실패
			alert(JSON.stringify(error));
		}); //ajax 통신을 이용해서 3개의 데이터를 json으로 변경하여 inset를 할거임.
	},
	update:function(){
		let data = {
			id : $("#id").val(),
			username: $("#username").val(),
			password: $("#password").val(),
			email: $("#email").val()
		};
	
		$.ajax({                                 
			type:"PUT",
			url:"/user/update",
			data:JSON.stringify(data), 
			contentType:"application/json;charset=utf-8", 
			dataType : "json" 
		}).done(function(resp){ 					 //성공         
			alert("회원수정이 완료되었습니다.");
			location.href="/";
		}).fail(function(error){                      //실패
			alert(JSON.stringify(error));
		});
	},
	
		
	
	
}
index.init();