package com.cos.blog.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import com.cos.blog.model.KakaoProfile;
import com.cos.blog.model.OAuthToken;
import com.cos.blog.model.User;
import com.cos.blog.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

//인증이 안된 사용자들이 출입 할 수 있는 경로를 /ayth 라는 경로 이하로만 허용 하겠다
//그냥 주소가 "/"이면 index.jsp 허용
//static 이하에 있는 것들 허용.js . img 등
@Controller
public class UserController {

	@Value("${cos.key}")
	private String cosKey;
	
	@Autowired
	private UserService userService;

	@Autowired
	private AuthenticationManager authenticationManager; // securutyConfig 에 @bean 으로 등록 함

	@GetMapping("/auth/joinForm")
	public String joinForm() {
		return "user/joinForm";
	}

	@GetMapping("/auth/loginForm")
	public String loginForm() {
		return "user/loginForm";
	}

	@GetMapping("/user/updateForm")
	public String updateForm() {
		return "user/updateForm";
	}

	@GetMapping("/auth/kakao/callback")
	public String kakaoCallback(String code) { // @ResponseBody를 리턴값 앞에 붙여 주면 DATA를 리턴해 주는 컨트롤러 함수가 된다.

		RestTemplate rt = new RestTemplate(); // post 방식으로 전송
		// HttpHeader 오브젝트 생성
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");

		// HttpBody 오브젝트 생성
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		params.add("grant_type", "authorization_code");
		params.add("client_id", "b3e5c0fe9fa2c2591a42725a399e7756");
		params.add("redirect_uri", "http://localhost:8080/auth/kakao/callback");
		params.add("code", code);

		// HttpHeader와 HttpBody 를 하나의 오브젝트에 담기
		HttpEntity<MultiValueMap<String, String>> kakaoTokenRequest = // param(body)값과 headers 값을 같는 entity가 된다.
				new HttpEntity<>(params, headers);

		// Http 요청하기 - post 방식
		ResponseEntity<String> response = rt.exchange("https://kauth.kakao.com/oauth/token", HttpMethod.POST,
				kakaoTokenRequest, String.class);
		// params.forEach((key, value) -> System.out.println(key + " : " + value));

		// Gson, Json Simple, ObjectMapper 라이브러리 사용
		ObjectMapper objectMapper = new ObjectMapper();
		OAuthToken oAuthToken = null;

		try {
			oAuthToken = objectMapper.readValue(response.getBody(), OAuthToken.class);
		} catch (JsonMappingException e) {

			e.printStackTrace();
		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}
		System.out.println(oAuthToken.getAccess_token());

		// return response.getBody();

		////////////////////////////////////////////////////////////////// 사용자 정보 가져 오기
		RestTemplate rt2 = new RestTemplate(); // post 방식으로 전송
		// HttpHeader 오브젝트 생성
		HttpHeaders headers2 = new HttpHeaders();
		headers2.add("Authorization", "Bearer " + oAuthToken.getAccess_token());
		headers2.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
		// System.out.println(headers2.getContentType());
		// HttpHeader와 HttpBody 를 하나의 오브젝트에 담기
		HttpEntity<MultiValueMap<String, String>> kakaoProfileRequest2 = // param(body)값과 headers 값을 같는 entity가 된다.
				new HttpEntity<>(headers2);

		// Http 요청하기 - post 방식

		ResponseEntity<String> response2 = rt2.exchange("https://kapi.kakao.com/v2/user/me", HttpMethod.POST,
				kakaoProfileRequest2, String.class);

		ObjectMapper objectMapper2 = new ObjectMapper();
		// objectMapper2.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
		// // 네이밍 전략 추가 (Snake -> Camel)
		KakaoProfile kakaoProfile = null;

		try {
			kakaoProfile = objectMapper2.readValue(response2.getBody(), KakaoProfile.class);
		} catch (JsonMappingException e) {

			e.printStackTrace();
		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}

		// User에서 필요한것은 username,password,email 이다.
		System.out.println(kakaoProfile.getId());
		System.out.println(kakaoProfile.kakao_account.getEmail());
		System.out.println(kakaoProfile.kakao_account.getEmail() + "_" + kakaoProfile.getId()); // 중복 아이디를 막기 위해 카카오로
																								// 로그인 한 사람은 다음과 같이 로콜
																								// 아이디를 저장한다.
		//UUID garbagePassword = UUID.randomUUID(); // 패스워드를 입시로 만들어 넣는다.
		//System.out.println(garbagePassword);

		User kakaoUser = User.builder()
				.username(kakaoProfile.kakao_account.getEmail() + "_" + kakaoProfile.getId())
				.password(cosKey)
				.email(kakaoProfile.kakao_account.getEmail())
				.oauth("kakao")
				.build();

		User orginUser = userService.회원찾기(kakaoUser.getUsername());

		if (orginUser.getUsername() == null) {
			userService.회원가입(kakaoUser);
			// return "회원가입완료";
		}

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(kakaoUser.getUsername(), cosKey));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		return "redirect:/";
	}

}
