package com.cos.blog.test;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
//사용자 요청에 ->Html파일 응답 
//@Controller


//사용자의 요청에 ->DATA응답
@RestController
public class HttpControllerTest {

	@GetMapping("/test/get")
	public String getTest(Member m) {
		return "get요청 id="+m.getId()+", "+m.getUsername();
		
	}
	@PostMapping("/test/post")

	/*
	 * public String postTest(@RequestBody String text) { 
	 * return text;
	 */
	
	  public String postTest(@RequestBody Member member) { //post는 바디에 담아 보내려면 (@RequestBody String text)를 사용 해야 한다. json형태로 받아 파싱할 수 있다. 있다.
		return "post요청 id="+member.getId()+", "+member.getUsername();
	 	
	}
	@PutMapping("/test/put")
	public String putTest() {
		return "put요청";
		
	}
	@DeleteMapping("/test/delete")
	public String deleteTest() {
		return "delete요청";
		
	}
}
