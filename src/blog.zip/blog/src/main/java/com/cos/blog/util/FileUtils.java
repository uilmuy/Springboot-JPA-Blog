package com.cos.blog.util;

import java.io.File;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cos.blog.dto.ResponseDto;

@Service
public class FileUtils {


	public static ResponseDto<Integer> fileUpload(List<MultipartFile> fileList) throws Exception {
		/*
		 * String user = (String) map.get("memWriter"); int board_no =
		 * (int)map.get("board_no");
		 * 
		 * List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		 * Map<String, Object> listMap = null;
		 */
		String FilePath = "C:/file/upload/";
		for (MultipartFile mf : fileList) {

			/*
			 * listMap = new HashMap<String,Object>(); listMap.put("boardNo", board_no);
			 * listMap.put("createUser", user); listMap.put("originalFileName",
			 * mf.getOriginalFilename());
			 * 
			 * // 저장이름 listMap.put("storedFileName", mf.getOriginalFilename());
			 * listMap.put("fileSize", mf.getSize());
			 * 
			 * list.add(listMap);
			 */

			// globals.properties

			File dest = new File((FilePath)+mf.getOriginalFilename());
			if (!dest.exists()) {
				dest.mkdirs(); // 디렉토리가 존재하지 않는다면 생성
				System.out.println("계속?");
			}
				
			
			/*
			 * listMap.put("file_path",mf.getOriginalFilename());
			 * listMap.put("real_file_path",dest);
			 */
			mf.transferTo(dest);
			
		}
		return new ResponseDto<Integer>(HttpStatus.OK.value(), 1);
	}

}
