package com.cos.blog.test;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//@Getter
//@Setter

@Data
@AllArgsConstructor //(생성자 생성)
@NoArgsConstructor
//@RequiredArgsConstructor //(final이 붙은 놈들에 대한 Constructor(생성자)를 만들어 준다.
public class Member {
	
	private  int id;
	private  String username;
	private  String password;
	private  String email;
	
}
 
