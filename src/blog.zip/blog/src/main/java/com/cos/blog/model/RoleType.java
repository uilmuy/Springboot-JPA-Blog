package com.cos.blog.model;

public enum RoleType {
	USER,ADMIN
}
