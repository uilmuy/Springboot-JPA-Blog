// JSON 데이터 서버에 전송
$("#searchBtn").click(function () {
  var vin = JSON.parse(localStorage.getItem("vin")) || [];
  console.log(vin);
  $.ajax({
    url: "server_url_here",
    method: "POST",
    data: JSON.stringify({ vin: vin }),
    contentType: "application/json",
    success: function (data) {
      console.log("Data sent to server: " + data);
    },
    error: function (xhr, status, error) {
      console.log("Error sending data to server: " + error);
    },
  });
});
