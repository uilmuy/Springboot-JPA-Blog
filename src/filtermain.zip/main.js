$(document).ready(function () {
  // 모달 팝업 열기
  $("#filterBtn").click(function () {
    $(".modal").css("display", "flex");
  });

  // 모달 팝업 닫기
  $("#modalConfirm").click(function () {
    $(".modal").css("display", "none");
    var inputVal = $("#modalInput").val();
    console.log(inputVal);

    // 필터링
    if (inputVal !== "") {
      $("#tableBody tr").filter(function () {
        $(this).toggle(
          $(this).text().toLowerCase().indexOf(inputVal.toLowerCase()) > -1
        );
      });

      // 결과를 filterData 요소에 추가
      var filterItem = $("<div></div>").addClass("filter-item");
      var textSpan = $("<span></span>").text(inputVal);
      var removeBtn = $("<button></button>").text("X");
      removeBtn.click(function () {
        filterItem.remove();
        $("#tableBody tr").show(); // 필터링 해제
        var vin = JSON.parse(localStorage.getItem("vin")) || [];
        var index = vin.indexOf(inputVal);
        if (index !== -1) {
          vin.splice(index, 1);
          localStorage.setItem("vin", JSON.stringify(vin));
        }
      });
      filterItem.append(textSpan);
      filterItem.append(removeBtn);
      $("#filterData").append(filterItem);

      // 입력 필드 초기화
      $("#modalInput").val("");

      // JSON 형식으로 데이터 추가
      var vin = JSON.parse(localStorage.getItem("vin")) || [];
      vin.push(inputVal);
      localStorage.setItem("vin", JSON.stringify(vin));
    } else {
      $("#tableBody tr").show();
    }

    // 모든 필터링 결과 출력
    var allFilterItems = "";
    $("#filterData div").each(function () {
      allFilterItems += $(this).text();
    });
    $("#filterData").show(); // 필터링 결과 출력
    console.log(allFilterItems);
  });

  // 테이블 데이터 추가
  for (var i = 1; i <= 5; i++) {
    var row = $("<tr></tr>");
    for (var j = 1; j <= 5; j++) {
      var cell = $("<td></td>").text("Data " + i + "-" + j);
      row.append(cell);
    }
    $("#tableBody").append(row);
  }

  // 필터링 데이터 복원
  var vin = JSON.parse(localStorage.getItem("vin")) || [];
  vin.forEach(function (data) {
    var filterItem = $("<div></div>").addClass("filter-item");
    var textSpan = $("<span></span>").text(data);
    var removeBtn = $("<button></button>").text("X");
    removeBtn.click(function () {
      filterItem.remove();
      $("#tableBody tr").show(); // 필터링 해제
      var vin = JSON.parse(localStorage.getItem("vin")) || [];
      var index = vin.indexOf(data);
      if (index !== -1) {
        vin.splice(index, 1);
        localStorage.setItem("vin", JSON.stringify(vin));
      }
    });
    filterItem.append(textSpan);
    filterItem.append(removeBtn);
    $("#filterData").append(filterItem);
  });
  $("#searchBtn").click(function () {
    alert(vin);
    //sendDataToServer();
  });
});
