package com.lottojjang.lottonumgenerator.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "winnerInfomation")
@Data
@AllArgsConstructor
@NoArgsConstructor // 빈 생성자 사용금지
@Builder
public class WinnerInfomation {

  // private Long id;

  private int yearOfIssue;
  @Id
  private int drwNo;
  @Temporal(TemporalType.TIMESTAMP)
  private Date drwNoDate;
  private int firstPrzwnerCo;
  private String firstPrizeM;
  private int secondPrzwnerCo;
  private String secondPrizeM;
  private int thirdPrzwnerCo;
  private String thirdPrizeM;
  private int w4thPrzwnerCo;
  private String w4thPrizeM;
  private int w5thPrzwnerCo;
  private String w5thPrizeM;
  private int bnusNo; // 보너스 번호
  private int drwtNo1;
  private int drwtNo2;
  private int drwtNo3;
  private int drwtNo4;
  private int drwtNo5;
  private int drwtNo6;

  // fod 펑션온디멘드

}