package com.lottojjang.lottonumgenerator.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lottojjang.lottonumgenerator.domain.SearchLottoNum;

public interface SearchLottoRepository extends JpaRepository<SearchLottoNum, Integer> {

}
