package com.lottojjang.lottonumgenerator.repository.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.lottojjang.lottonumgenerator.domain.LottoNumberET;
import com.lottojjang.lottonumgenerator.domain.QLottoNumberET;
import com.lottojjang.lottonumgenerator.repository.CreateLottoNumbersRepositoryExtend;
import com.querydsl.jpa.impl.JPAQueryFactory;

@Repository
public class CreateLottoNumbersRepositoryExtendImpl implements
    CreateLottoNumbersRepositoryExtend {

  Logger logger = LoggerFactory.getLogger(CreateLottoNumbersRepositoryExtendImpl.class);

  private final JPAQueryFactory queryFactory;

  public CreateLottoNumbersRepositoryExtendImpl(JPAQueryFactory jpaQueryFactory) {
    this.queryFactory = jpaQueryFactory;
  }

  @Override
  public List<LottoNumberET> findByValue(LottoNumberET lwe) {

    // QLottoNumberET lottoNumberET = new QLottoNumberET("lottoNumberET"); // 이렇게
    // 사용하거나 아래 처럼 사용하거나..
    QLottoNumberET lottoNumberET = QLottoNumberET.lottoNumberET;

    return queryFactory.selectFrom(lottoNumberET).where(lottoNumberET.drwtNo1.eq(lwe.getDrwtNo1())).fetch();
  }

  @Override
  public int isExist(LottoNumberET lwe) {
    // return 0;

    QLottoNumberET lottoNumberET = QLottoNumberET.lottoNumberET;

    return queryFactory.selectFrom(lottoNumberET)
        .where(lottoNumberET.drwtNo1.eq(lwe.getDrwtNo1())
            .and(lottoNumberET.drwtNo2.eq(lwe.getDrwtNo2()))
            .and(lottoNumberET.drwtNo3.eq(lwe.getDrwtNo3()))
            .and(lottoNumberET.drwtNo4.eq(lwe.getDrwtNo4()))
            .and(lottoNumberET.drwtNo5.eq(lwe.getDrwtNo5()))
            .and(lottoNumberET.drwtNo6.eq(lwe.getDrwtNo6())))
        .fetch().size();

  }

}
