package com.lottojjang.lottonumgenerator.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lottojjang.lottonumgenerator.aop.ApiExecutionTime;
import com.lottojjang.lottonumgenerator.domain.LottoWinnerNum;
import com.lottojjang.lottonumgenerator.domain.User;
import com.lottojjang.lottonumgenerator.dto.lotto.LottoWinner;
import com.lottojjang.lottonumgenerator.dto.lotto.LottowinConfirmation;
import com.lottojjang.lottonumgenerator.handler.ex.CustomApiException;
import com.lottojjang.lottonumgenerator.repository.LottoWinnerInfoRepository;
import com.lottojjang.lottonumgenerator.repository.MyLottoRepository;
import com.lottojjang.lottonumgenerator.repository.SearchLottoRepository;
import com.lottojjang.lottonumgenerator.repository.UserRepository;
import com.lottojjang.lottonumgenerator.util.LottoInfoCollector;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service // IoC 등록
@Transactional(rollbackFor = Exception.class)
public class LottoWinnerInfoService {

  private static Logger logger = LoggerFactory.getLogger(LottoWinnerInfoService.class);
  private final MyLottoRepository myLottoRepository;
  private final SearchLottoRepository searchLottoRepository;
  private final UserRepository userRepository;
  private final LottoWinnerInfoRepository lwir;

  // public LottoWinnerInfoService(LottoWinnerInfoRepository lwir) {
  // this.lwir = lwir;
  // }

  /**
   * 추첨정보 저장.
   *
   * @param lwn 저장 할 추첨 결과 정보
   * @return 성공시 true
   * @exception
   * @see
   **/
  public boolean save(LottoWinnerNum lwn) {

    return lwir.save(lwn);
  }

  /**
   * 추첨 정보 전체 리스트
   *
   * @return LottoWinnerNum list
   * @exception
   * @see
   **/
  public List<LottoWinnerNum> getAllList() {
    return lwir.findAll();
  }

  @ApiExecutionTime
  @Transactional
  public boolean saveAllWinnerInfo() {
    // 마지막 회차 정보를 얻어 오고
    int max = LottoInfoCollector.getLastLottoDrwNo();
    Long dbMax = lwir.lastRoundNum();
    int starNum = 1;

    if (max == 0) {
      return false;
    }
    if (dbMax != null) {
      starNum = starNum + dbMax.intValue();
    }

    for (int iCount = starNum; iCount <= max; iCount++) {

      LottoWinner lw = Optional.ofNullable(LottoInfoCollector.getLottoWinnerInfo(iCount)).orElseThrow(null);
      LottoWinnerNum lwn = LottoWinnerNum.builder(lw).build();
      this.save(lwn);

    }
    logger.debug("디비에 저장된 데이터는 : {}건 입니다.", max - starNum + 1);
    return true;
  }

  /**
   * 사용자 로또번호 당첨 조회
   *
   * @param lottowinConfirmation,arrWinNum 사용자 로또 번호, 회차 당첨번호 6자리
   * @return LottowinConfirmation 사용자 로또번호 당첨 내용
   * @exception
   * @see
   **/
  public LottowinConfirmation chkNumMatch(LottowinConfirmation lottowinConfirmation, int[] arrWinNum) {

    lottowinConfirmation = sortNumAsc(lottowinConfirmation);
    lottowinConfirmation.setTargetDrwNo(arrWinNum[0]);

    for (int i = 1; i < arrWinNum.length; i++) {
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo1()) {
        lottowinConfirmation.setWin1(true);
        lottowinConfirmation.setWinCount(lottowinConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo2()) {
        lottowinConfirmation.setWin2(true);
        lottowinConfirmation.setWinCount(lottowinConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo3()) {
        lottowinConfirmation.setWin3(true);
        lottowinConfirmation.setWinCount(lottowinConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo4()) {
        lottowinConfirmation.setWin4(true);
        lottowinConfirmation.setWinCount(lottowinConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo5()) {
        lottowinConfirmation.setWin5(true);
        lottowinConfirmation.setWinCount(lottowinConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo6()) {
        lottowinConfirmation.setWin6(true);
        lottowinConfirmation.setWinCount(lottowinConfirmation.getWinCount() + 1);
      }
    }
    return lottowinConfirmation;
  }

  public LottowinConfirmation getWinNum(LottowinConfirmation lottowinConfirmation, int[] arrWinNum) {

    lottowinConfirmation = sortNumAsc(lottowinConfirmation);
    LottowinConfirmation eConfirmation = new LottowinConfirmation();
    eConfirmation.setTargetDrwNo(arrWinNum[0]);
    eConfirmation.setDrwtNo1(arrWinNum[1]);
    eConfirmation.setDrwtNo2(arrWinNum[2]);
    eConfirmation.setDrwtNo3(arrWinNum[3]);
    eConfirmation.setDrwtNo4(arrWinNum[4]);
    eConfirmation.setDrwtNo5(arrWinNum[5]);
    eConfirmation.setDrwtNo6(arrWinNum[6]);

    for (int i = 1; i < arrWinNum.length; i++) {
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo1()) {
        eConfirmation.setWin1(true);
        eConfirmation.setWinCount(eConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo2()) {
        eConfirmation.setWin2(true);
        eConfirmation.setWinCount(eConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo3()) {
        eConfirmation.setWin3(true);
        eConfirmation.setWinCount(eConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo4()) {
        eConfirmation.setWin4(true);
        eConfirmation.setWinCount(eConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo5()) {
        eConfirmation.setWin5(true);
        eConfirmation.setWinCount(eConfirmation.getWinCount() + 1);
      }
      if (arrWinNum[i] == lottowinConfirmation.getDrwtNo6()) {
        eConfirmation.setWin6(true);
        eConfirmation.setWinCount(eConfirmation.getWinCount() + 1);
      }
    }
    return eConfirmation;
  }

  public int[] winNumByRoundArr(int round) {

    Optional<LottoWinnerNum> lottoWinnerNum = lwir.findById(round);
    int[] arrWinNum = new int[7];

    if (lottoWinnerNum.isPresent()) {

      LottoWinnerNum winEntity = lottoWinnerNum.get();
      arrWinNum[0] = winEntity.getDrwNo(); // 비교회차
      arrWinNum[1] = winEntity.getDrwtNo1();
      arrWinNum[2] = winEntity.getDrwtNo2();
      arrWinNum[3] = winEntity.getDrwtNo3();
      arrWinNum[4] = winEntity.getDrwtNo4();
      arrWinNum[5] = winEntity.getDrwtNo5();
      arrWinNum[6] = winEntity.getDrwtNo6();
      return arrWinNum;

    } else {

      throw new CustomApiException("해당 회차 번호가 존재 하지 않습니다.");

    }
  }

  public LottoWinnerNum winNumByRound(int round) {

    Optional<LottoWinnerNum> lottoWinnerNum = lwir.findById(round);
    if (lottoWinnerNum.isPresent()) {
      return lottoWinnerNum.get();
    } else {
      throw new CustomApiException("해당 회차 번호가 존재 하지 않습니다.");
    }
  }

  public ArrayList<LottowinConfirmation> oneYearNumChk(LottowinConfirmation lottowinConfirmation) {

    lottowinConfirmation = sortNumAsc(lottowinConfirmation);
    int lastnum = lwir.lastRoundNum().intValue();
    int ftnum = lastnum - 52;
    int arrset = 0;

    ArrayList<LottowinConfirmation> arrLottowinConfirmation = new ArrayList<LottowinConfirmation>();

    for (int i = ftnum; i <= lastnum; i++) {
      log.debug("회차번호는:{}", i);
      int[] arrWinNum = new int[7];
      arrWinNum = winNumByRoundArr(i);
      LottowinConfirmation lottowinnum = getWinNum(lottowinConfirmation, arrWinNum);

      if (lottowinnum.getWinCount() >= 2) {
        arrLottowinConfirmation.add(arrset, lottowinnum);
        arrset++;
      }
    }

    return arrLottowinConfirmation;
  }

  // public ArrayList<LottowinConfirmation> 역대번호검색(LottowinConfirmation
  // lottowinConfirmation) {

  // lottowinConfirmation = sortNumAsc(lottowinConfirmation);
  // List<LottoWinnerNum> lottoNumberET =
  // lwir.findByValue(lottowinConfirmation.toEntity());
  // lottoNumberET.forEach(s -> System.out.println(s));
  // return null;
  // }

  public boolean saveMyNumber(ArrayList<LottowinConfirmation> arrLottowinConfirmation, String username) {
    // TODO 리턴타입 정해주세요.
    Optional<User> user = userRepository.findByUsername(username);

    if (user.isPresent()) {
      for (int i = 0; i < arrLottowinConfirmation.size(); i++) {
        myLottoRepository.save(sortNumAsc(arrLottowinConfirmation.get(i)).toMylottoNum(user.get()));
      }
    } else {
      throw new CustomApiException("해당 아이디가 존재하지 않습니다. 다시시도 해 주세요.");
    }
    return user.isPresent();
  }

  public void saveSearchNumber(ArrayList<LottowinConfirmation> arrLottowinConfirmation, String username) {
    // TODO 번호저장 마무리하기
    Optional<User> user = userRepository.findByUsername(username);
    if (user.isPresent()) {
      for (int i = 0; i < arrLottowinConfirmation.size(); i++) {
        searchLottoRepository.save(arrLottowinConfirmation.get(i).toSearchLottoNum(user.get()));
      }
    } else {
      if (username.equals("Guest")) {
        for (int i = 0; i < arrLottowinConfirmation.size(); i++) {
          searchLottoRepository.save(arrLottowinConfirmation.get(i).toSearchLottoNum(null));
        }
      } else {
        throw new CustomApiException("==검색한번호저장== : 로또번호가 저장되지 않았습니다.");
      }
    }
  }

  private LottowinConfirmation sortNumAsc(LottowinConfirmation lottowinConfirmation) {

    int[] lotto = new int[6];
    lotto[0] = lottowinConfirmation.getDrwtNo1();
    lotto[1] = lottowinConfirmation.getDrwtNo2();
    lotto[2] = lottowinConfirmation.getDrwtNo3();
    lotto[3] = lottowinConfirmation.getDrwtNo4();
    lotto[4] = lottowinConfirmation.getDrwtNo5();
    lotto[5] = lottowinConfirmation.getDrwtNo6();
    Arrays.sort(lotto);
    lottowinConfirmation.setDrwtNo1(lotto[0]);
    lottowinConfirmation.setDrwtNo2(lotto[1]);
    lottowinConfirmation.setDrwtNo3(lotto[2]);
    lottowinConfirmation.setDrwtNo4(lotto[3]);
    lottowinConfirmation.setDrwtNo5(lotto[4]);
    lottowinConfirmation.setDrwtNo6(lotto[5]);

    /*
     * try {
     * 
     * Class targetClass = Class.forName(lottowinConfirmation.getClass().getName());
     * 
     * Field[] field = targetClass.getDeclaredFields();
     * 
     * for (int i = 1; i <= 6; i++) {
     * for (int j = 0; j < field.length; j++) {
     * String findField = field[j].getName();
     * String iWMethod = "drwtNo" + i;
     * if (findField.equals(iWMethod)) {
     * 
     * }
     * }
     * }
     * } catch (ClassNotFoundException | NullPointerException e) {
     * new CustomApiException("클래스를 찾을수 없습니다.");
     * }
     * for (int i = 1; i < 6; i++) {
     * System.out.println(lotto[i]);
     * }
     */
    return lottowinConfirmation;
  }

}