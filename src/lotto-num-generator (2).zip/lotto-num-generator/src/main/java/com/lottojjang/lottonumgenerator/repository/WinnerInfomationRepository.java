package com.lottojjang.lottonumgenerator.repository;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.lottojjang.lottonumgenerator.domain.WinnerInfomation;

public interface WinnerInfomationRepository extends JpaRepository<WinnerInfomation, Integer> {

  @Query(value = "SELECT * FROM winnerinfomation w  WHERE drwNo=:drwNo", nativeQuery = true)
  Optional<WinnerInfomation> findByDrwNoOne(@Param("drwNo") int drwNo);

  @Query(value = "select drwNo  from winnerinfomation  ORDER by drwNo desc", nativeQuery = true)
  ArrayList<Integer> findByDrwNoList();

}