package com.lottojjang.lottonumgenerator.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lottojjang.lottonumgenerator.domain.Visit;

public interface VisitRepository extends JpaRepository<Visit, Integer> {

}
