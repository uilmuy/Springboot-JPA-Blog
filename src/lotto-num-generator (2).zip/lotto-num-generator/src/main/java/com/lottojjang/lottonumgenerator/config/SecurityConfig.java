package com.lottojjang.lottonumgenerator.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.lottojjang.lottonumgenerator.handler.LoginSuccessHandler;

@Configuration // IoC 빈(bean)을 등록
@EnableWebSecurity // 필터 체인 관리 시작 어노테이션 *웹시큐리티 활성화
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true) // 특정 주소 접근시 권한 및 인증을 위한 어노테이션 활성화
public class SecurityConfig extends WebSecurityConfigurerAdapter {

  @Bean // 해당 메서드의 리턴 되는 오브젝트를 IOC 로 등록하게 된다
  public BCryptPasswordEncoder encodePwd() {
    return new BCryptPasswordEncoder();
  }
  // @Override
  // // WebSecurity : 필터 체인 관련 전역 설정을 처리할 수 있는 API 제공
  // public void configure(WebSecurity web) {
  // // 매칭되는 uri가 필터 체인을 적용하지 않도록 설정
  // web.ignoring().antMatchers("/assets/**");
  // }

  @Override
  protected void configure(HttpSecurity http) throws Exception {

    http.csrf().disable();
    http.authorizeRequests()
        .antMatchers("/user/password-reset-form", "/user/passwordresetform", "/user/password-reset").anonymous()
        .antMatchers("/user/**").authenticated() // "/user/**" 주소로 들어오면 authenticated() 인증이 필요하단 말 *인증만 되면 들어 갈수 있는 주소
        // .antMatchers("/admin/**").access("hasRole('ROLE_ADMIN') or
        // hasRole('ROLE_USER')")
        // .antMatchers("/admin/**").access("hasRole('ROLE_ADMIN') and
        // hasRole('ROLE_USER')")
        // .antMatchers("/manager/**").access("hasRole('ROLE_ADMIN') or
        // hasRole('ROLE_MANAGER')") // * access 는 권한이 있어야 들어 갈 수 있는 주소
        // .antMatchers("/admin/**").access("hasRole('ROLE_ADMIN')")
        .anyRequest()
        .permitAll() // 상단 설정 이외의 접근은 모두 권한 허용
        .and()
        .formLogin() // 로그인은 하지 않으면 로그인 페이지로 이동 하게 한다.
        .loginPage("/login-form") // /login 주소를 추가되면 시큐리티 가 낚아채서 대신 로그인 해준다
        .loginProcessingUrl("/login")
        // .defaultSuccessUrl("/");
        .successHandler(new LoginSuccessHandler());

    // .and() // 구글 로그인을 위한 시큐리티 설정 oauth2Login()
    // .oauth2Login()
    // .loginPage("/loginForm") //구글 로그인 완료후 후처리 필요. 코드받기->엑세스토큰(인증됨)->사용자 프로필 정보
    // 가져와->그정보를 토대로 자동으로 회원가입을 시켜주거나(추가 내용을 더 받을 수 있다.) 로그인을 시킴 ##구글로그인은 코드를 받지 않고,
    // 엑세스토큰+사용자정보를 한번에 받는다.
    // .userInfoEndpoint()
    // .userService(PrincipalOauth2UserService);
    // //<-----https://youtu.be/nVCEJv6eA-w
    http.logout()
        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
        .logoutSuccessUrl("/login-form")
        .invalidateHttpSession(true);
  }
}
