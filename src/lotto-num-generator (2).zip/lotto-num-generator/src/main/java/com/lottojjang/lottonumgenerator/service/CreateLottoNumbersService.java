package com.lottojjang.lottonumgenerator.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lottojjang.lottonumgenerator.dto.lotto.LottoNumberBuilder;
import com.lottojjang.lottonumgenerator.dto.lotto.LottoNumberBuilderImpl;
import com.lottojjang.lottonumgenerator.repository.CreateLottoNumbersRepository;
import com.lottojjang.lottonumgenerator.repository.LottoWinnerInfoRepository;

@Service
public class CreateLottoNumbersService {

  private static Logger logger = LoggerFactory.getLogger(CreateLottoNumbersService.class);

  @Autowired
  private CreateLottoNumbersRepository clnr;

  // @Autowired
  private LottoWinnerInfoRepository lwir;

  public boolean createLottoNumber() {

    List<Integer> includeNumberList = new ArrayList<Integer>();
    List<Integer> excludeNumberList = new ArrayList<Integer>();

    // logger.debug("findAll() list size:{}", lwir.findAll().size());

    // lwir.findByValue();

    // includeNumberList.add(1);
    // includeNumberList.add(3);
    // includeNumberList.add(4);

    // excludeNumberList.add(45);

    LottoNumberBuilder lottoNumberBuilder = new LottoNumberBuilderImpl(clnr,
        lwir);
    // lottoNumberBuilder.createLottoNumber(5, excludeNumberList,
    // includeNumberList);
    lottoNumberBuilder.aaaa();

    return true;
  }

  public int getListTest() {
    LottoNumberBuilder lottoNumberBuilder = new LottoNumberBuilderImpl(clnr,
        lwir);
    return lottoNumberBuilder.aaaa();
  }

}
