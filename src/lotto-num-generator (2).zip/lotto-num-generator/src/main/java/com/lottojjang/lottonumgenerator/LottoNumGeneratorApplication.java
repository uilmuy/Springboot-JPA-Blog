package com.lottojjang.lottonumgenerator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.lottojjang.lottonumgenerator.service.LottoWinnerInfoService;

import lombok.extern.slf4j.Slf4j;

@EnableJpaAuditing
@Slf4j
@SpringBootApplication
@EnableScheduling
public class LottoNumGeneratorApplication extends SpringBootServletInitializer {

  @Autowired
  private LottoWinnerInfoService lottoWinnerInfoService;

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(LottoNumGeneratorApplication.class);
  }

  public static void main(String[] args) {
    SpringApplication.run(LottoNumGeneratorApplication.class, args);
  }

  @Scheduled(cron = "10 * * * * *")
  public void numImportSchedule() {
    log.debug("==회차 정보 수집==");

    try {
      if (lottoWinnerInfoService.saveAllWinnerInfo()) {
        log.debug("회차 정보 수집 *성공*");
      }
    } catch (Exception e) {
      e.getStackTrace();
      log.debug("회차 정보 수집 *실패*[" + e.getMessage() + "]");
    }
  }
}
