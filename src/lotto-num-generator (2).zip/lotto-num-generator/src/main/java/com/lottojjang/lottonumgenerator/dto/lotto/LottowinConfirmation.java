package com.lottojjang.lottonumgenerator.dto.lotto;

import javax.validation.constraints.NotNull;

import com.lottojjang.lottonumgenerator.domain.MyLottoNum;
import com.lottojjang.lottonumgenerator.domain.SearchLottoNum;
import com.lottojjang.lottonumgenerator.domain.User;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LottowinConfirmation { // TODO 나중에 validation 확인 하기

  @NotNull
  private int drwtNo1;
  private boolean win1;

  @NotNull
  private int drwtNo2;
  private boolean win2;

  @NotNull
  private int drwtNo3;
  private boolean win3;

  @NotNull
  private int drwtNo4;
  private boolean win4;

  @NotNull
  private int drwtNo5;
  private boolean win5;

  @NotNull
  private int drwtNo6;
  private boolean win6;

  private int targetDrwNo; // 비교회차

  private int winCount; // 당첨번호 숫자

  private boolean mBought;// 구매여부
  // @Autowired
  // private LottoNumberET lottoNumberET;

  // public LottoNumberET toEntity() {
  // // LottoNumberET lottoNumberET = new LottoNumberET();
  // lottoNumberET.setDrwtNo1(drwtNo1);
  // lottoNumberET.setDrwtNo2(drwtNo2);
  // lottoNumberET.setDrwtNo3(drwtNo3);
  // lottoNumberET.setDrwtNo4(drwtNo4);
  // lottoNumberET.setDrwtNo5(drwtNo5);
  // lottoNumberET.setDrwtNo6(drwtNo6);
  // return lottoNumberET;
  // }

  public MyLottoNum toMylottoNum(User user) {
    MyLottoNum myLottoNum = new MyLottoNum();
    myLottoNum.setDrwtNo1(drwtNo1);
    myLottoNum.setDrwtNo2(drwtNo2);
    myLottoNum.setDrwtNo3(drwtNo3);
    myLottoNum.setDrwtNo4(drwtNo4);
    myLottoNum.setDrwtNo5(drwtNo5);
    myLottoNum.setDrwtNo6(drwtNo6);
    myLottoNum.setUser(user);
    return myLottoNum;
  }

  public SearchLottoNum toSearchLottoNum(User user) {
    SearchLottoNum searchLottoNum = new SearchLottoNum();
    searchLottoNum.setDrwtNo1(drwtNo1);
    searchLottoNum.setDrwtNo2(drwtNo2);
    searchLottoNum.setDrwtNo3(drwtNo3);
    searchLottoNum.setDrwtNo4(drwtNo4);
    searchLottoNum.setDrwtNo5(drwtNo5);
    searchLottoNum.setDrwtNo6(drwtNo6);
    searchLottoNum.setTargetDrwNo(targetDrwNo);
    searchLottoNum.setMBought(mBought);
    if (winCount > 2) {
      searchLottoNum.setWinWhether(true);
    } else {
      searchLottoNum.setWinWhether(false);
    }
    searchLottoNum.setUser(user);
    return searchLottoNum;
  }

}
