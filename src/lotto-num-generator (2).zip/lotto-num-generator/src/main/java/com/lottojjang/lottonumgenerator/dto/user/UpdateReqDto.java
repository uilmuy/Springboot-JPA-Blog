package com.lottojjang.lottonumgenerator.dto.user;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data // Getter, Setter, toString
public class UpdateReqDto {

  private int id;

  @Pattern(regexp = "[a-zA-Z0-9]{4,20}", message = "유저네임은 한글이 들어갈 수 없습니다.")
  @Size(min = 4, max = 20)
  @NotBlank
  private String username;

  @Size(min = 4, max = 20)
  @NotBlank
  private String password;

  private String newpassword;

  @Size(min = 10, max = 60)
  @NotBlank // @NotNull, @NotEmpty 두개의 조합
  @Email
  private String email;

  @Size(min = 0, max = 20)
  private String nickname;

}
