package com.lottojjang.lottonumgenerator.config;

import javax.persistence.EntityManager;

import com.lottojjang.lottonumgenerator.repository.LottoWinnerInfoRepository;
import com.lottojjang.lottonumgenerator.repository.impl.LottoWinnerInfoRepositoryImpl;
import com.querydsl.jpa.impl.JPAQueryFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {

  private EntityManager em;

  // springboot에서 자동으로 EntityManager에 매핑 해 줌.
  public SpringConfig(EntityManager em) {
    this.em = em;
  }

  // LottoWinnerInfoRepositoryImpl에서 @Repository 사용하면 이 내용이 필요 없음.
  // 아래 처럼 사용을 했을 때 구현체를 갈아 껴주는 형태로 사용하기 편하게 됨.
  @Bean
  public LottoWinnerInfoRepository lottoWinnerInfoRepository() {
    return new LottoWinnerInfoRepositoryImpl(em);
  }

  @Bean
  public JPAQueryFactory jpaQueryFactory() {
    return new JPAQueryFactory(em);
  }
}
