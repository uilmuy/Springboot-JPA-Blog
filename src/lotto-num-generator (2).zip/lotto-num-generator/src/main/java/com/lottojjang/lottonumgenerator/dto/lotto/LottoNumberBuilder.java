package com.lottojjang.lottonumgenerator.dto.lotto;

import java.util.List;

import com.lottojjang.lottonumgenerator.domain.LottoNumber;

public interface LottoNumberBuilder {

  /**
   * 번호 생성
   *
   * @param quantity           생성 갯수
   * @param excludeNumbersList 제외 할 번호 리스트
   * @param includeNumbersList 포함 할 번호 리스트 6개를 초과 할 수 없음.
   * @return 생성한 로또 번호 리스트
   * @exception
   **/
  public List<LottoNumber> createLottoNumber(int quantity,
      List<Integer> includeNumbersList, List<Integer> excludeNumbersList);

  /**
   * 번호 생성
   *
   * @param quantity           생성 갯수
   * @param excludeNumbersList 제외 할 번호 리스트
   * @param includeNumbersList 포함 할 번호 리스트 6개를 초과 할 수 없음.
   * @return 생성한 로또 번호 리스트
   * @exception
   **/
  public List<LottoNumber> createLottoNumber(int quantity,
      List<Integer> includeNumbersList, List<Integer> excludeNumbersList,
      int sumRangeStart, int sumRangeEnd);

  public int aaaa();

}
