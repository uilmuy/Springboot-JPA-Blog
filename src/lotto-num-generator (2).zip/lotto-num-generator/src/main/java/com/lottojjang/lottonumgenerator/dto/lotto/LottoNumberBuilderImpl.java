package com.lottojjang.lottonumgenerator.dto.lotto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.lottojjang.lottonumgenerator.domain.LottoNumber;
import com.lottojjang.lottonumgenerator.domain.LottoNumberET;
import com.lottojjang.lottonumgenerator.repository.CreateLottoNumbersRepository;
import com.lottojjang.lottonumgenerator.repository.LottoWinnerInfoRepository;

@Component
@Primary
public class LottoNumberBuilderImpl implements LottoNumberBuilder {

  Logger logger = LoggerFactory.getLogger(LottoNumberBuilderImpl.class);

  private final int NUMBERS_RANGE_1TO10 = 0;
  private final int NUMBERS_RANGE_11TO20 = 1;
  private final int NUMBERS_RANGE_21TO30 = 2;
  private final int NUMBERS_RANGE_31TO40 = 3;
  private final int NUMBERS_RANGE_41TO45 = 4;
  private final int NUMBERS_RANGE_21TO45 = 5;
  private final int NUMBERS_RANGE_31TO45 = 6;
  private final int NUMBERS_RANGE_1TO20 = 7;
  private final int NUMBERS_RANGE_11TO30 = 8;
  private final int NUMBERS_RANGE_21TO40 = 9;
  private final int NUMBERS_RANGE_11TO40 = 10;

  private final int NUMBERS_RANGE_1TO9 = 11;
  private final int NUMBERS_RANGE_10TO19 = 12;
  private final int NUMBERS_RANGE_20TO29 = 13;
  private final int NUMBERS_RANGE_40TO45 = 14;

  private final int NUMBERS_RANGE_5TO25 = 15;
  private final int NUMBERS_RANGE_15TO30 = 16;
  private final int NUMBERS_RANGE_20TO40 = 17;
  private final int NUMBERS_RANGE_30TO45 = 18;

  private final int NUMBERS_RANGE_10TO30 = 19;
  private final int NUMBERS_RANGE_15TO35 = 20;
  private final int NUMBERS_RANGE_20TO45 = 21;

  private final int[] srcNumbers1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
  private final int[] srcNumbers2 = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
  private final int[] srcNumbers3 = { 21, 22, 23, 24, 25, 26, 27, 28, 29, 30 };
  private final int[] srcNumbers4 = { 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 };
  private final int[] srcNumbers5 = { 41, 42, 43, 44, 45 };

  private final int[] srcNumbers6 = { 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
      35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45 };

  private final int[] srcNumbers7 = { 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45 };

  private final int[] srcNumbers8 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
      18, 19, 20 };

  private final int[] srcNumbers9 = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
      26, 27, 28, 29, 30 };

  private final int[] srcNumbers10 = { 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
      35, 36, 37, 38, 39, 40 };

  private final int[] srcNumbers11 = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
      25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 };

  private final int[] srcNumbers12 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
  private final int[] srcNumbers13 = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 };
  private final int[] srcNumbers14 = { 20, 21, 22, 23, 24, 25, 26, 27, 28, 29 };
  private final int[] srcNumbers15 = { 40, 41, 42, 43, 44, 45 };

  private final int[] srcNumbers16 = { 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
      17, 18, 19, 20, 21, 22, 23, 24, 25 };

  private final int[] srcNumbers17 = { 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
      25, 26, 27, 28, 29, 30 };

  private final int[] srcNumbers18 = { 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
      31, 32, 33, 34, 35, 36, 37, 38, 39, 40 };

  private final int[] srcNumbers19 = { 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
      41, 42, 43, 44, 45 };

  private final int[] srcNumbers20 = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
      21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
      41, 42, 43, 44, 45 };

  private final int[] srcNumbers21 = { 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
      25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35 };

  private final int[] srcNumbers22 = { 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
      31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45 };

  private CreateLottoNumbersRepository clnr;

  private LottoWinnerInfoRepository lwir;

  public LottoNumberBuilderImpl(CreateLottoNumbersRepository clnr,
      LottoWinnerInfoRepository lwir) {

    this.clnr = clnr;
    this.lwir = lwir;

  }

  // findByValue 를 테스트 하기 위해
  public int aaaa() {

    LottoNumber lw = LottoNumber.builder()
        .drwNo(2)
        .drwtNo1(1)
        .drwtNo2(2)
        .drwtNo3(3)
        .drwtNo4(4)
        .drwtNo5(5)
        .drwtNo6(6)
        .build();

    LottoNumberET lwn = LottoNumberET.builder(lw).build();
    lwn.setDrwtNo1(4);

    List<LottoNumberET> aaa = clnr.findByValue(lwn);

    logger.debug("aaa size:{}", aaa.size());

    return aaa.size();
  }

  @Override
  public List<LottoNumber> createLottoNumber(int quantity, List<Integer> includeNumbersList,
      List<Integer> excludeNumbersList, int sumRangeStart, int sumRangeEnd) {
    // TODO 각 자릿수 합계에 대한 처리 로직이 들어 가야 한다.
    return null;
  }

  @Override
  public List<LottoNumber> createLottoNumber(int quantity, List<Integer> includeNumbersList,
      List<Integer> excludeNumbersList) {

    // 꼭 포함 시켜야 하는 번호가 6개를 초과 하는지 확인.(1게임은 숫자 6개로 구성)
    if (includeNumbersList != null && includeNumbersList.size() > 6) {
      logger.error("max count 6 of include numbers.");
      return null;
    }

    // includeNumbersList 에 값이 있는 경우와 없는 경우에 대해서 번호 뽑기 처리가 달라 져야 한다.
    // includeNumbersList에 값이 있는 경우엔 includeNumbersList 갯수를 제외한 나머지 빈 자릿수를
    // 채울 때에는 NUMBERS_RANGE_1TO10 ~ NUMBERS_RANGE_11TO40 사이의 값 들 중 랜덤하게 가져와서
    // 그에 해당 하는 배열의 값을 가져오도록 한다. 이렇게 처리 하지 않고 기존 로직대로 처리를 하면
    // includeNumbersList 에 해당 하는 번호대에 속하는 번호를 영원히 가져오지 못하게 된다.

    // LottoNumber lottoNumber = lottoNumberCreate(includeNumbersList,
    // excludeNumbersList, 130, 140);

    // logger.debug("만든 번호: " + lottoNumber.getDrwtNo1() + " " +
    // lottoNumber.getDrwtNo2() + " " +
    // +lottoNumber.getDrwtNo3() + " " + lottoNumber.getDrwtNo4() + " " +
    // +lottoNumber.getDrwtNo5() + " " + lottoNumber.getDrwtNo6());

    // lottoNumber = lottoNumberCreateWithIncludeNumbers(includeNumbersList,
    // excludeNumbersList);

    // logger.debug("만든 번호: " + lottoNumber.getDrwtNo1() + " " +
    // lottoNumber.getDrwtNo2() + " " +
    // +lottoNumber.getDrwtNo3() + " " + lottoNumber.getDrwtNo4() + " " +
    // +lottoNumber.getDrwtNo5() + " " + lottoNumber.getDrwtNo6());
    List<LottoNumber> listLottoNumber = new ArrayList<>();
    for (int iCount = 0; iCount < quantity; iCount++) {

      // LottoNumber lottoNumber = lottoNumberCreate(excludeNumbersList,
      // NUMBERS_RANGE_1TO9,
      // NUMBERS_RANGE_1TO9,
      // NUMBERS_RANGE_10TO19,
      // NUMBERS_RANGE_20TO29,
      // NUMBERS_RANGE_40TO45,
      // NUMBERS_RANGE_40TO45, 130, 139);

      // LottoNumber lottoNumber = lottoNumberCreate(excludeNumbersList,
      // NUMBERS_RANGE_5TO25,
      // NUMBERS_RANGE_15TO30,
      // NUMBERS_RANGE_20TO40,
      // NUMBERS_RANGE_30TO45,
      // NUMBERS_RANGE_30TO45,
      // NUMBERS_RANGE_30TO45, 180, 190);

      LottoNumber lottoNumber = lottoNumberCreate(excludeNumbersList,
          NUMBERS_RANGE_1TO20,
          NUMBERS_RANGE_1TO20,
          NUMBERS_RANGE_10TO30,
          NUMBERS_RANGE_15TO35,
          NUMBERS_RANGE_20TO45,
          NUMBERS_RANGE_30TO45, 120, 130);

      LottoNumberET lwn = LottoNumberET.builder(lottoNumber).build();
      if (lwir.findByValue(lwn).size() <= 0) {

        // 같은 번호가 있는 경우 제외
        if (clnr.isExist(lwn) > 0) {
          logger.debug("있는 번호라 제외: " + lwn.getDrwtNo1() + " " + lwn.getDrwtNo2() + " " +
              +lwn.getDrwtNo3() + " " + lwn.getDrwtNo4() + " " +
              +lwn.getDrwtNo5() + " " + lwn.getDrwtNo6());
          continue;
        }

        logger.debug("만든 번호: " + lwn.getDrwtNo1() + " " + lwn.getDrwtNo2() + " " +
            +lwn.getDrwtNo3() + " " + lwn.getDrwtNo4() + " " +
            +lwn.getDrwtNo5() + " " + lwn.getDrwtNo6());

        clnr.save(lwn);
        lottoNumber.setId(lwn.getId());
        lottoNumber.setGood(lwn.isGood());
        lottoNumber.setCreateDate(lwn.getCreateDate());
        lottoNumber.setDrwNo(lwn.getDrwNo());
        lottoNumber.setDrwtNo1(lwn.getDrwtNo1());
        lottoNumber.setDrwtNo2(lwn.getDrwtNo2());
        lottoNumber.setDrwtNo3(lwn.getDrwtNo3());
        lottoNumber.setDrwtNo4(lwn.getDrwtNo4());
        lottoNumber.setDrwtNo5(lwn.getDrwtNo5());
        lottoNumber.setDrwtNo6(lwn.getDrwtNo6());
        listLottoNumber.add(iCount, lottoNumber);
      }

      // logger.debug("====================================================");
    }

    return listLottoNumber;
  }

  /**
   * 로또 1게임 생성 꼭 포함을 해야 하는 번호가 있는 경우
   *
   * @param includeNumbersList 포함을 시켜야 하는 번호 리스트
   * @param excludeNumbersList 제외 시켜야 할 번호 리스트
   * @return 로또 1게임 생성
   * @exception
   * @see
   **/
  private LottoNumber lottoNumberCreateWithIncludeNumbers(List<Integer> includeNumbersList,
      List<Integer> excludeNumbersList) {

    return lottoNumberCreate(includeNumbersList, excludeNumbersList, 0, 0);
  }

  /**
   * 로또 1게임 생성
   *
   * @param includeNumbersList 포함을 시켜야 하는 번호 리스트
   * @param excludeNumbersList 제외 시켜야 할 번호 리스트
   * @param sumRangeStart      생성한 번호의 자릿수 총 합의 시작 범위
   * @param sumRangeEnd        생성한 번호의 자릿수 총 합의 끝 범위
   * @return 로또 1게임 생성
   * @exception
   * @see
   **/
  private LottoNumber lottoNumberCreate(List<Integer> includeNumbersList,
      List<Integer> excludeNumbersList, int sumRangeStart, int sumRangeEnd) {

    // 포함되어야 할 수들을 제외하고 몇개를 만들어야 하는지
    int getDigitCount = 6 - includeNumbersList.size();

    Random generator = new Random();
    boolean check = true;
    List<Integer> tempIncludeNumbers = new ArrayList<Integer>();

    while (check) {

      tempIncludeNumbers.clear();

      for (Integer includeNumber : includeNumbersList) {
        tempIncludeNumbers.add(includeNumber);
      }

      for (int iCount = 0; iCount < getDigitCount; iCount++) {
        int temp = getNumber(tempIncludeNumbers, excludeNumbersList, generator.nextInt(10));
        tempIncludeNumbers.add(temp);
      }

      // 둘 다 0인 경우는 합산에 대한 체크를 하지 않는다.
      if (sumRangeStart == 0 && sumRangeEnd == 0) {
        check = false;
      } else {
        int tot = 0;

        for (Integer number : tempIncludeNumbers) {
          tot = tot + number.intValue();
        }

        if (sumRangeStart <= tot && tot <= sumRangeEnd) {
          check = false;
        }
      }
    }

    return sortNumbers(tempIncludeNumbers);

  }

  /**
   * 로또 1게임 생성
   *
   * @param excludeNumbersList 제외 시켜야 할 번호 리스트
   * @param numbersRange1      번호 뽑기시 대상이 되는 번호범위 index 값
   * @param numbersRange2      번호 뽑기시 대상이 되는 번호범위 index 값
   * @param numbersRange3      번호 뽑기시 대상이 되는 번호범위 index 값
   * @param numbersRange4      번호 뽑기시 대상이 되는 번호범위 index 값
   * @param numbersRange5      번호 뽑기시 대상이 되는 번호범위 index 값
   * @param numbersRange6      번호 뽑기시 대상이 되는 번호범위 index 값
   * @param sumRangeStart      생성한 번호의 자릿수 총 합의 시작 범위
   * @param sumRangeEnd        생성한 번호의 자릿수 총 합의 끝 범위
   * @return 로또 1게임 생성
   * @exception
   * @see
   **/
  private LottoNumber lottoNumberCreate(List<Integer> excludeNumbersList,
      int numbersRange1, int numbersRange2, int numbersRange3, int numbersRange4,
      int numbersRange5, int numbersRange6, int sumRangeStart, int sumRangeEnd) {

    boolean check = true;
    List<Integer> tempIncludeNumbers = new ArrayList<Integer>();

    while (check) {

      tempIncludeNumbers.clear();

      tempIncludeNumbers.add(getNumber(tempIncludeNumbers, excludeNumbersList, numbersRange1));
      tempIncludeNumbers.add(getNumber(tempIncludeNumbers, excludeNumbersList, numbersRange2));
      tempIncludeNumbers.add(getNumber(tempIncludeNumbers, excludeNumbersList, numbersRange3));
      tempIncludeNumbers.add(getNumber(tempIncludeNumbers, excludeNumbersList, numbersRange4));
      tempIncludeNumbers.add(getNumber(tempIncludeNumbers, excludeNumbersList, numbersRange5));
      tempIncludeNumbers.add(getNumber(tempIncludeNumbers, excludeNumbersList, numbersRange6));

      int tot = 0;

      for (Integer number : tempIncludeNumbers) {
        tot = tot + number.intValue();
      }

      // logger.debug("{}, {}, {}, {}, {}, {} tot:{}",
      // tempIncludeNumbers.get(0).intValue(),
      // tempIncludeNumbers.get(1).intValue(), tempIncludeNumbers.get(2).intValue(),
      // tempIncludeNumbers.get(3).intValue(), tempIncludeNumbers.get(4).intValue(),
      // tempIncludeNumbers.get(5).intValue(), tot);

      if (sumRangeStart <= tot && tot <= sumRangeEnd) {
        check = false;
      }

    }

    return sortNumbers(tempIncludeNumbers);
  }

  /**
   * 정렬 해서 LottoNumber return
   *
   * @param numbers 정렬 할 대상
   * @return 정렬 해서 LottoNumber return
   * @exception
   * @see
   **/
  private LottoNumber sortNumbers(List<Integer> numbers) {

    int[] tempIndex = { numbers.get(0).intValue(), numbers.get(1).intValue(),
        numbers.get(2).intValue(), numbers.get(3).intValue(),
        numbers.get(4).intValue(), numbers.get(5).intValue() };

    int i, j, temp;

    for (i = 0; i < tempIndex.length - 1; i++) {
      for (j = 0; j < tempIndex.length - 1 - i; j++) {
        if (tempIndex[j] > tempIndex[j + 1]) {
          temp = tempIndex[j];
          tempIndex[j] = tempIndex[j + 1];
          tempIndex[j + 1] = temp;
        }
      }
    }

    LottoNumber lottoNumber = LottoNumber.builder()
        .drwtNo1(tempIndex[0])
        .drwtNo2(tempIndex[1])
        .drwtNo3(tempIndex[2])
        .drwtNo4(tempIndex[3])
        .drwtNo5(tempIndex[4])
        .drwtNo6(tempIndex[5])
        .createDate(new Date())
        .isGood(false)
        .build();

    return lottoNumber;
  }

  /**
   * 포함 해야 할 번호가 있으면 셋팅을 한다.
   *
   * @param quantity           생성 갯수
   * @param includeNumbersList 포함 할 번호 리스트 6개를 초과 할 수 없음.
   * @return LottoNumber list
   * @exception
   * @see
   **/
  private List<LottoNumber> setIncludeNumbers(int quantity, List<Integer> includeNumbersList) {

    List<LottoNumber> returnList = new ArrayList<LottoNumber>();

    for (int iCount = 0; iCount < quantity; iCount++) {
      LottoNumber lottoNumber = LottoNumber.builder()
          .drwtNo1(0)
          .drwtNo2(0)
          .drwtNo3(0)
          .drwtNo4(0)
          .drwtNo5(0)
          .drwtNo6(0)
          .build();

      // 꼭 포함시켜야 하는 번호 셋팅
      if (includeNumbersList != null) {
        for (int iCount2 = 0; iCount2 < includeNumbersList.size(); iCount2++) {
          int getNum = includeNumbersList.get(iCount2).intValue();

          if (iCount2 == 0) {
            lottoNumber.setDrwtNo1(getNum);
          } else if (iCount2 == 1) {
            lottoNumber.setDrwtNo2(getNum);
          } else if (iCount2 == 2) {
            lottoNumber.setDrwtNo3(getNum);
          } else if (iCount2 == 3) {
            lottoNumber.setDrwtNo4(getNum);
          } else if (iCount2 == 4) {
            lottoNumber.setDrwtNo5(getNum);
          } else if (iCount2 == 5) {
            lottoNumber.setDrwtNo6(getNum);
          }
        }

        lottoNumber.setEmptyDigit(lottoNumber.getEmptyDigit() - includeNumbersList.size());
      }

      returnList.add(lottoNumber);
    }

    return returnList;
  }

  /**
   * 번호를 생성한다. ( 한 자릿수 )
   *
   * @param alreadyNumberList 이미 뽑아 놓은 번호 list (중복 생성을 막기 위해)
   * @param excludeNumberList 포함 시키면 안될 번호 list
   * @param numbersRange      번호 생성 대상 배열의 범위 지정
   * @return 1~45 사이 범위의 번호 한자릿수 반환
   * @exception
   * @see
   **/
  private int getNumber(List<Integer> alreadyNumberList, List<Integer> excludeNumberList, int numbersRange) {

    int resultNumber = 0;

    Random generator = new Random();

    boolean check = true;

    while (check) {

      // 일단 번호를 뽑고
      if (resultNumber == 0) {
        if (numbersRange == NUMBERS_RANGE_1TO10)
          resultNumber = srcNumbers1[generator.nextInt(10)];
        else if (numbersRange == NUMBERS_RANGE_11TO20)
          resultNumber = srcNumbers2[generator.nextInt(10)];
        else if (numbersRange == NUMBERS_RANGE_21TO30)
          resultNumber = srcNumbers3[generator.nextInt(10)];
        else if (numbersRange == NUMBERS_RANGE_31TO40)
          resultNumber = srcNumbers4[generator.nextInt(10)];
        else if (numbersRange == NUMBERS_RANGE_41TO45)
          resultNumber = srcNumbers5[generator.nextInt(5)];
        else if (numbersRange == NUMBERS_RANGE_21TO45)
          resultNumber = srcNumbers6[generator.nextInt(25)];
        else if (numbersRange == NUMBERS_RANGE_31TO45)
          resultNumber = srcNumbers7[generator.nextInt(15)];
        else if (numbersRange == NUMBERS_RANGE_1TO20)
          resultNumber = srcNumbers8[generator.nextInt(20)];
        else if (numbersRange == NUMBERS_RANGE_11TO30)
          resultNumber = srcNumbers9[generator.nextInt(20)];
        else if (numbersRange == NUMBERS_RANGE_21TO40)
          resultNumber = srcNumbers10[generator.nextInt(20)];
        else if (numbersRange == NUMBERS_RANGE_11TO40)
          resultNumber = srcNumbers11[generator.nextInt(30)];
        else if (numbersRange == NUMBERS_RANGE_1TO9)
          resultNumber = srcNumbers12[generator.nextInt(9)];
        else if (numbersRange == NUMBERS_RANGE_10TO19)
          resultNumber = srcNumbers13[generator.nextInt(10)];
        else if (numbersRange == NUMBERS_RANGE_20TO29)
          resultNumber = srcNumbers14[generator.nextInt(10)];
        else if (numbersRange == NUMBERS_RANGE_40TO45)
          resultNumber = srcNumbers15[generator.nextInt(6)];
        else if (numbersRange == NUMBERS_RANGE_5TO25)
          resultNumber = srcNumbers16[generator.nextInt(21)];
        else if (numbersRange == NUMBERS_RANGE_15TO30)
          resultNumber = srcNumbers17[generator.nextInt(16)];
        else if (numbersRange == NUMBERS_RANGE_20TO40)
          resultNumber = srcNumbers18[generator.nextInt(21)];
        else if (numbersRange == NUMBERS_RANGE_30TO45)
          resultNumber = srcNumbers19[generator.nextInt(16)];
        else if (numbersRange == NUMBERS_RANGE_10TO30)
          resultNumber = srcNumbers20[generator.nextInt(36)];
        else if (numbersRange == NUMBERS_RANGE_15TO35)
          resultNumber = srcNumbers21[generator.nextInt(21)];
        else if (numbersRange == NUMBERS_RANGE_20TO45)
          resultNumber = srcNumbers22[generator.nextInt(26)];

      }

      // 이미 뽑아 놓은 번호에 중복인지 체크.
      if (isNumberEqualInList(alreadyNumberList, resultNumber)) {
        resultNumber = 0;
        continue;
      }

      // 금지 번호와 중복인지 체크
      if (isNumberEqualInList(excludeNumberList, resultNumber)) {
        resultNumber = 0;
        continue;
      }

      check = false;
    }

    return resultNumber;
  }

  /**
   * list 내에 같은 번호가 있는지 확인을 한다.
   *
   * @param list      비교 해야 할 list
   * @param targetNum 비교 대상 number
   * @return 같은 번호가 있는 경우 true
   * @exception
   * @see
   **/
  private boolean isNumberEqualInList(List<Integer> list, int targetNum) {

    if (list == null)
      return false;

    for (Integer sourceNum : list) {
      if (sourceNum.intValue() == targetNum)
        return true;
    }

    return false;
  }

}
