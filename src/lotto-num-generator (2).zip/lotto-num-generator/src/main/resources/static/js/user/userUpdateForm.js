let valid = {
  username: {
    state: false,
    msg: "",
  },
  password: {
    state: false,
    msg: "",
  },
};

// $("#username").focusout(() => {
//   usernameSameCheck();
// });

// $("#password").focusout(() => {
//   passwordChk();
// });

// $("#same-password").focusout(() => {
//   passwordSameCheck();
// });

// $("#nickname").focusout(() => {   //닉네임 채크 유무 (닉네임을 사용할까?)
//   usernameSameCheck();
// });

function validation() {
  // $(".my_error_box").html("이거 올라가나?");
  // $(".my_error_box").removeClass("my_hidden");
  const handleError = (response) => {
    if (!response.ok) {
      alert("회원수정을 실패 하였습니다.");
      console.log(response);
      alert(response.state);
      throw Error(response.statusText);
    } else {
      console.log(response.statusText);
      alert("회원수정이 완료되었습니다.");
      location.href = "/logout";
      return response;
    }
  };
  fetch("/user/update", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      id: $("#id").val(),
      username: $("#username").val(),
      password: $("#password").val(),
      newpassword: $("#newpassword").val(),
      email: $("#email").val(),
      nickname: $("#nickname").val(),
    }),
  })
    .then(handleError)
    .catch((err) => {
      console.error("실패:", err);
    });
}

// async function usernameSameCheck() {
//   let username = $("#username").val();

//   let response = await fetch(
//     `/api/user/username-same-check?username=${username}`
//   );
//   let responseParse = await response.json();

//   if (response.status === 200) {
//     if (!responseParse) {
//       valid.username.state = false;
//       valid.username.msg = "유저네임이 중복되었습니다.";
//     } else {
//       valid.username.state = true;
//       valid.username.msg = "";
//     }
//   } else {
//     alert(responseParse);
//   }
// }

// function passwordSameCheck() {
//   let password = $("#password").val();
//   let samePassword = $("#same-password").val();

//   if (password === samePassword) {
//     valid.password.state = true;
//     valid.password.msg = "";
//   } else {
//     valid.password.state = false;
//     valid.password.msg = "패스워드가 동일하지 않습니다.";
//   }
// }
